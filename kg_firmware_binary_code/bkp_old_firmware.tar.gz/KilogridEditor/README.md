## Kilogrid Editor

GUI Application to edit cell config files visually.
It uses an original encoding/decoding rule for mapping (subcell_id, subcell_state) to (cell_data) and vice versa.

The rule is defined as two functions, `encode` and `decode`, in the C-style header file, 'src/conversion.h'.
You can use the header in your projects (or codes) too.
