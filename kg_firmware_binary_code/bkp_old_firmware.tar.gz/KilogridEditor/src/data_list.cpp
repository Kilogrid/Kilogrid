#include "data_list.hpp"

#include <algorithm>


Data::Data(QString name, QString state, QColor color)
  : _name(name), _state(state), _color(color)
{}


QString Data::header(int section)
{
  switch(section) {
    case 0:
      return "Color";
    case 1:
      return "Label";
    case 2:
      return "Data";
  }
  return QVariant().toString();
}


DataList::DataList(QObject* parent)
  : QAbstractListModel(parent)
{}


int DataList::rowCount(const QModelIndex&) const
{
  return _data.size();
}


int DataList::columnCount(const QModelIndex&) const
{
  return Data::NUMBER_OF_COLUMNS;
}


QVariant DataList::data(const QModelIndex& index, int role) const
{
  if(index.row() >= rowCount() || index.column() >= columnCount()) return QVariant();
  if(role == Qt::CheckStateRole) return QVariant();
  switch(index.column()) {
    case 0:
      if(role == Qt::DecorationRole) return _data.at(index.row()).color();
      break;
    case 1:
      if(role == Qt::DisplayRole) return _data.at(index.row()).name();
      break;
    case 2:
      if(role == Qt::DisplayRole) return _data.at(index.row()).state();
      break;
  }

  return QVariant();
}


QVariant DataList::headerData(int section, Qt::Orientation orientation, int role) const
{
  if(role == Qt::DisplayRole && orientation == Qt::Horizontal) {
    return Data::header(section);
  }
  return QVariant();
}


Qt::ItemFlags DataList::flags(const QModelIndex& index) const
{
//  return Qt::ItemIsEnabled | Qt::ItemIsSelectable;
  // Only data label is editable for ver 1.0
  auto flag = Qt::ItemIsEnabled | Qt::ItemIsSelectable;
  if(index.column() == 1) flag |= Qt::ItemIsEditable;
  return flag;
}


bool DataList::setData(const QModelIndex &index, const QVariant &value, int role)
{
  if(role != Qt::EditRole) return false;
  auto& data = _data[index.row()];
  switch(index.column()) {
    case 0:
      data.changeColor(QColor(value.toString()));
      break;
    case 1:
      data.changeName(value.toString());
      break;
    case 2:
      data.changeState(value.toString());
      break;
  }

  emit dataChanged(index, index);
  return true;
}


bool DataList::removeRows(int row, int count, const QModelIndex& parent)
{
  QAbstractItemModel::removeRows(row, count, parent);
  if(row + count >= _data.size()) return false;
  for(auto i = 0; i < count; ++i) _data.removeAt(row);
  return true;
}


QColor DataList::get_state_color(Cell::subcell_state_t state) const
{
  for(auto i = 0; i < _data.size(); ++i) {
    if(_data[i].state().toUInt(nullptr, 16) == state) {
      return _data[i].color();
    }
  }
  return QColor("Yellow");
}