#ifndef KILOGRID_EDITOR_CONVERSION_H
#define KILOGRID_EDITOR_CONVERSION_H

#include <stdint.h>

typedef uint8_t _kilogrid_cell_data_t;
typedef uint8_t _kilogrid_subcell_id_t;
typedef uint8_t _kilogrid_subcell_state_t;

typedef struct {
  _kilogrid_subcell_id_t    id;
  _kilogrid_subcell_state_t state;
} kilogrid_subcell_tuple;


/***********************************************
 * Encoding/Decoding rule
 *
 * 0x00 = 0b 000000  00
 *          |------||--|
 *           state   id
 *
 * Ex)
 * 0x05 = 0b00000101 :: id = 1, state = 0x01
 ***********************************************/
#define KILOGRID_CONVERSION_SHIFT 2
#define KILOGRID_CONVERSION_MASK  3  // => 0b00000011


static inline
_kilogrid_cell_data_t encode(_kilogrid_subcell_id_t id,
                             _kilogrid_subcell_state_t state)
{
  return (state << KILOGRID_CONVERSION_SHIFT) | id;
}


static inline
kilogrid_subcell_tuple decode(_kilogrid_cell_data_t data)
{
  kilogrid_subcell_tuple ret;
  ret.id    = (data & KILOGRID_CONVERSION_MASK);
  ret.state = (data >> KILOGRID_CONVERSION_SHIFT);
  return ret;
}

#undef KILOGRID_CONVERSION_MASK
#undef KILOGRID_CONVERSION_SHIFT

#endif  /* KILOGRID_EDITOR_CONVERSION_H */