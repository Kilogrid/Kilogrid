#include <algorithm>
#include "cell.hpp"

#include <QtGlobal>


/* Default conversion rule is defined in conversion.cpp. */
typename Cell::data_t encode(typename Cell::subcell_id_t, typename Cell::subcell_state_t);

bool Cell::is_valid_data(subcell_id_t id, subcell_state_t state)
{
  return encode(id, state) < DATA_LIMIT;
}


namespace {
  constexpr Cell::subcell_state_t DEFAULT_STATE = 0xff;
}


Cell::Cell()
  : Cell(0, 0)
{}


Cell::Cell(coordinate_t x, coordinate_t y)
  : _x(x), _y(y)
{
  for(subcell_id_t i = 0; i < NUMBER_OF_SUBCELLS; ++i) {
    clear_state(i);
  }
}


void Cell::clear_state(subcell_id_t id)
{
  Q_ASSERT(id < NUMBER_OF_SUBCELLS);
  _subcell_states[id] = DEFAULT_STATE;
}



void Cell::swap(Cell& cell)
{
  std::swap(cell._x, this->_x);
  std::swap(cell._y, this->_y);
  std::swap(cell._subcell_states, this->_subcell_states);
}


void Cell::invert_x()
{
  std::swap(_subcell_states[0], _subcell_states[1]);
  std::swap(_subcell_states[2], _subcell_states[3]);
}


void Cell::invert_y()
{
  std::swap(_subcell_states[0], _subcell_states[2]);
  std::swap(_subcell_states[1], _subcell_states[3]);
}


bool has_any_data(const Cell& cell) {
  for(typename Cell::subcell_id_t id = 0; id < Cell::NUMBER_OF_SUBCELLS; ++id) {
    if(has_data(cell, id)) return true;
  }
  return false;
}
