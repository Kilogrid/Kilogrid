#ifndef DATALIST_HPP
#define DATALIST_HPP

#include <QAbstractListModel>
#include <QColor>
#include <QtGui>
#include <QList>

#include "cell.hpp"


class Data {

  public:
  static constexpr int NUMBER_OF_COLUMNS = 3;

  static QString header(int section);

  Data(QString name, QString state, QColor color = QColor());

  const QString& name() const { return _name; }
  const QString& state() const { return _state; }
  const QColor&  color() const { return _color; }

  void changeName(const QString& name) { _name = name; }
  void changeState(const QString& state) { _state = state; }
  void changeColor(const QColor& color) { _color = color; }

  private:
  QString _name;
  QString _state;
  QColor  _color;
};


class DataList : public QAbstractListModel
{
  public:
  explicit DataList(QObject* parent = nullptr);

  int rowCount(const QModelIndex& parent = QModelIndex()) const override;
  int columnCount(const QModelIndex &parent = QModelIndex()) const override;

  QVariant data(const QModelIndex &index, int role) const override;
  QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;

  Qt::ItemFlags flags(const QModelIndex &index) const override;
  bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;

  bool removeRows(int row, int count, const QModelIndex& parent = QModelIndex()) override;

  void update(int row, const Data& data)
  {
    if(row >= rowCount()) return;
    _data[row] = data;
  }

  void add_data(const Data& data)
  {
    _data.append(data);
  }

  const QString& name(int row) const { return _data[row].name(); }
  Cell::subcell_state_t state(int row) const { return _data[row].state().toInt(nullptr, 16); }
  const QColor& color(int row) const { return _data[row].color(); }

  QColor get_state_color(Cell::subcell_state_t state) const;

  private:
  QList<Data> _data;
};

#endif // DATALIST_HPP