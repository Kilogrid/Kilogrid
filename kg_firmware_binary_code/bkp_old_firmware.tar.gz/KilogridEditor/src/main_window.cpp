#include "main_window.hpp"

#include <vector>
#include <random>

#include <QGridLayout>
#include <QMenuBar>
#include <QGroupBox>
#include <QRadioButton>
#include <QPushButton>
#include <QLabel>
#include <QTreeView>
#include <QFileDialog>
#include <QMessageBox>

#include "kilogrid.hpp"
#include "data_list.hpp"
#include "kilogrid_viewer.hpp"
#include "configurationparser.h"


namespace {
  std::mt19937 rnd((std::random_device())());
}


MainWindow::MainWindow(QWidget *parent)
  : QMainWindow(parent),
    _data_list(new DataList),
    _kilogrid(new Kilogrid)
{}


MainWindow::~MainWindow()
{
  delete _data_list;
  delete _kilogrid;
}


void MainWindow::initialize()
{
  setMenuBar(createMenuBar());

  QWidget* window = new QWidget(this);
  QGridLayout* layout = new QGridLayout(window);

  layout->addWidget(createModeGroup(), 0, 0);

  layout->addWidget(createToolGroup(), 1, 0);

  layout->addWidget(createDataGroup(), 2, 0, 1, 1);

  layout->addWidget(createKilogridViewer(), 0, 1, 3, 6);

  window->setLayout(layout);
  setCentralWidget(window);

  setMinimumHeight(this->height());
}


/***** Menu *****/
QMenuBar* MainWindow::createMenuBar()
{
  auto ret = new QMenuBar(this);

  auto menu = new QMenu(tr("Menu"), ret);
  {
    auto action_resize = new QAction(tr("Resize kilogrid (not implemented yet)"), menu);
    menu->addAction(action_resize);
    action_resize->setDisabled(true);
  }
  menu->addSeparator();
  {
    auto action_import = new QAction(tr("Import config"), menu);
    connect(action_import, SIGNAL(triggered()), this, SLOT(menu_import()));
    menu->addAction(action_import);
  }
  {
    auto action_export = new QAction(tr("Export config"), menu);
    connect(action_export, SIGNAL(triggered()), this, SLOT(menu_export()));
    menu->addAction(action_export);
  }
  auto edit = new QMenu("Edit");
  {
    auto action_invert_x = new QAction(tr("Invert X"), edit);
    connect(action_invert_x, SIGNAL(triggered(bool)), this, SLOT(edit_invert_x()));
    edit->addAction(action_invert_x);
  }
  {
    auto action_invert_y = new QAction(tr("Invert Y"), edit);
    connect(action_invert_y, SIGNAL(triggered(bool)), this, SLOT(edit_invert_y()));
    edit->addAction(action_invert_y);
  }

  ret->addMenu(menu);
  ret->addMenu(edit);

  return ret;
}


void MainWindow::menu_import()
{
  auto filename = QFileDialog::getOpenFileName(this,
                                               tr("Import Kilogrid Config"),
                                               QDir::homePath(),
                                               tr("Kilogrid config (*.kconf)"));
  if(filename.isEmpty()) return;

  QFile file(filename);
  try {
    _kilogrid->load_from(file);
  } catch(ConfigurationParserException& pe) {
    QMessageBox::critical(this, "Parser error", pe.message);
  }

  _kilogrid_viewer->repaint();
}


void MainWindow::menu_export()
{
  auto filename = QFileDialog::getSaveFileName(this,
                                               tr("Export Kilogrid Config"),
                                               QDir::homePath(),
                                               tr("Kilogrid config (*.kconf)"));
  if(filename.isEmpty()) return;

  QFile file(filename);
  if(!_kilogrid->export_to(file)) {
    QMessageBox::critical(this, "Export error", QString("Could not export to the file: %1").arg(filename));
  }
}


void MainWindow::edit_invert_x()
{
  _kilogrid->invert_x();
  _kilogrid_viewer->repaint();
}


void MainWindow::edit_invert_y()
{
  _kilogrid->invert_y();
  _kilogrid_viewer->repaint();
}


/***** Mode *****/
QGroupBox* MainWindow::createModeGroup()
{
  auto ret        = new QGroupBox("Mode", this);

  _mode_set   = new QRadioButton("Set", ret);
  _mode_clear = new QRadioButton("Clear", ret);

  _mode_set->setChecked(true);
  _mode = mode_state_t::MODE_SET;

  MainWindow::connect(_mode_set,   SIGNAL(pressed()), this, SLOT(switch_mode_set()));
  MainWindow::connect(_mode_clear, SIGNAL(pressed()), this, SLOT(switch_mode_clear()));

  auto layout     = new QHBoxLayout(ret);
  layout->addWidget(_mode_set);
  layout->addWidget(_mode_clear);
  ret->setLayout(layout);

  ret->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);

  return ret;
}


void MainWindow::switch_mode_set()
{
  _mode = mode_state_t::MODE_SET;
  _tool_random_empty->setEnabled(true);
  _data_group->setEnabled(true);
}


void MainWindow::switch_mode_clear()
{
  _mode = mode_state_t::MODE_CLEAR;
  _tool_random_empty->setEnabled(false);
  _data_group->setEnabled(false);
}


/***** Tool *****/
QGroupBox* MainWindow::createToolGroup()
{
  auto ret = new QGroupBox("Tool", this);

  // Toggled
  _tool_subcell  = new QPushButton("Subcell", ret);
  _tool_cell     = new QPushButton("Cell", ret);
  _tool_row      = new QPushButton("Row", ret);
  _tool_column   = new QPushButton("Column", ret);

  _tool_subcell->setCheckable(true);
  _tool_cell->setCheckable(true);
  _tool_row->setCheckable(true);
  _tool_column->setCheckable(true);

  // Set default state
  _tool_subcell->setChecked(true);
  _tool = tool_state_t::SUBCELL;

  connect(_tool_subcell, SIGNAL(clicked(bool)), this, SLOT(select_subcell(bool)));
  connect(_tool_cell,    SIGNAL(clicked(bool)), this, SLOT(select_cell(bool)));
  connect(_tool_row,     SIGNAL(clicked(bool)), this, SLOT(select_row(bool)));
  connect(_tool_column,  SIGNAL(clicked(bool)), this, SLOT(select_column(bool)));

  // Direct action
  auto label         = new QLabel("----- Utilities -----", ret);
  _tool_all          = new QPushButton("All", ret);
  _tool_random_empty = new QPushButton("Rand empty", ret);
  _tool_random_all   = new QPushButton("Rand all", ret);

  connect(_tool_all,          SIGNAL(clicked()), this, SLOT(select_all()));
  connect(_tool_random_empty, SIGNAL(clicked()), this, SLOT(select_random_empty()));
  connect(_tool_random_all,   SIGNAL(clicked()), this, SLOT(select_random_all()));

  auto layout = new QGridLayout(ret);
  layout->addWidget(_tool_subcell, 0, 0);
  layout->addWidget(_tool_cell, 1, 0);
  layout->addWidget(_tool_row, 2, 0);
  layout->addWidget(_tool_column, 3, 0);
  layout->addWidget(label, 0, 1, Qt::AlignCenter);
  layout->addWidget(_tool_all, 1, 1);
  layout->addWidget(_tool_random_empty, 2, 1);
  layout->addWidget(_tool_random_all, 3, 1);
  ret->setLayout(layout);

  ret->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
  return ret;
}


void MainWindow::select_subcell(bool)
{
  _tool_subcell->setChecked(true);
  _tool_cell->setChecked(false);
  _tool_row->setChecked(false);
  _tool_column->setChecked(false);
  _tool = tool_state_t::SUBCELL;
}


void MainWindow::select_cell(bool)
{
  _tool_subcell->setChecked(false);
  _tool_cell->setChecked(true);
  _tool_row->setChecked(false);
  _tool_column->setChecked(false);
  _tool = tool_state_t::CELL;
}


void MainWindow::select_row(bool)
{
  _tool_subcell->setChecked(false);
  _tool_cell->setChecked(false);
  _tool_row->setChecked(true);
  _tool_column->setChecked(false);
  _tool = tool_state_t::ROW;
}


void MainWindow::select_column(bool)
{
  _tool_subcell->setChecked(false);
  _tool_cell->setChecked(false);
  _tool_row->setChecked(false);
  _tool_column->setChecked(true);
  _tool = tool_state_t::COLUMN;
}


void MainWindow::select_all()
{
  for(coordinate_t x = 0; x < _kilogrid->max_x(); ++x) {
    for(coordinate_t y = 0; y < _kilogrid->max_y(); ++y) {
      for(subcell_id_t id = 0; id < Cell::NUMBER_OF_SUBCELLS; ++id) {
        if(!put_subcell_data(x, y, id)) goto END_OF_LOOP;
      }
    }
  }
  END_OF_LOOP:
  _kilogrid_viewer->repaint();
}


void MainWindow::select_random_empty()
{
  using data_t = std::tuple<coordinate_t, coordinate_t, subcell_id_t>;
  std::vector<data_t> empty_subcells;
  empty_subcells.reserve(_kilogrid->max_x() * _kilogrid->max_y() * Cell::NUMBER_OF_SUBCELLS);

  for(coordinate_t x = 0; x < _kilogrid->max_x(); ++x) {
    for(coordinate_t y = 0; y < _kilogrid->max_y(); ++y) {
      for(subcell_id_t id = 0; id < Cell::NUMBER_OF_SUBCELLS; ++id) {
        if(!has_data(_kilogrid->cell(x, y), id)) {
          empty_subcells.emplace_back(data_t(x, y, id));
        }
      }
    }
  }

  if(empty_subcells.size() <= 0) return;

  std::uniform_int_distribution<> index_dist(0, empty_subcells.size() - 1);
  auto& data = empty_subcells[index_dist(rnd)];
  put_subcell_data(std::get<0>(data), std::get<1>(data), std::get<2>(data));

  _kilogrid_viewer->repaint();
}


void MainWindow::select_random_all()
{
  static std::uniform_int_distribution<> id_dist(0, Cell::NUMBER_OF_SUBCELLS - 1);
  std::uniform_int_distribution<> x_dist(0, _kilogrid->max_x() - 1),
                                  y_dist(0, _kilogrid->max_y() - 1);

  coordinate_t x  = x_dist(rnd), y = y_dist(rnd);
  subcell_id_t id = id_dist(rnd);

  put_subcell_data(x, y, id);
  _kilogrid_viewer->repaint();
}


/***** Data *****/
QGroupBox* MainWindow::createDataGroup()
{
  _data_group  = new QGroupBox("Data", this);

  _data_viewer = new QTreeView(this);
  _data_viewer->setModel(_data_list);
  _data_viewer->setColumnWidth(0, 50);
  _data_viewer->setColumnWidth(1, 100);
  _data_viewer->setColumnWidth(2, 100);

//  _data_add    = new QPushButton("Add");
//  _data_modify = new QPushButton("Modify");
//  _data_clear  = new QPushButton("Clear");

//  connect(_data_add,    SIGNAL(clicked(bool)), this, SLOT(data_add()));
//  connect(_data_modify, SIGNAL(clicked(bool)), this, SLOT(data_modify()));
//  connect(_data_clear,  SIGNAL(clicked(bool)), this, SLOT(data_clear()));

  auto layout = new QGridLayout(_data_group);
  layout->addWidget(_data_viewer, 0, 0, 1, 3);
//  layout->addWidget(_data_add, 1, 0);
//  layout->addWidget(_data_modify, 1, 1);
//  layout->addWidget(_data_clear, 1, 2);
  _data_group->setLayout(layout);
  _data_group->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

  // Default data set for ver. 1.0
  _data_list->add_data(Data("State 1", "0x00", QColor("Red")));
  _data_list->add_data(Data("State 2", "0x01", QColor("Green")));
  _data_list->add_data(Data("State 3", "0x02", QColor("Blue")));
  _data_list->add_data(Data("State 4", "0x03", QColor("Yellow")));
  _data_list->add_data(Data("State 5", "0x04", QColor("Cyan")));
  _data_list->add_data(Data("State 6", "0x05", QColor("Magenta")));
  _data_list->add_data(Data("State 7", "0x06", QColor("White")));
  _data_list->add_data(Data("State 8", "0x07", QColor("Black")));
  // [TODO] make Add/Modify/Clear button enabled
  // Or not neccessary?

  return _data_group;
}


void MainWindow::data_add()
{
  // TODO: impl.
  // Or not neccessary?
  _kilogrid_viewer->repaint();
}


void MainWindow::data_modify()
{
  // TODO: impl.
  // Or not neccessary?
  _kilogrid_viewer->repaint();
}


void MainWindow::data_clear()
{
  // TODO: impl.
  // Or not neccessary?
  _kilogrid->clear();
  _kilogrid_viewer->repaint();
}


/***** Edit via KilogridViewer *****/
KilogridViewer* MainWindow::createKilogridViewer()
{
  _kilogrid_viewer = new KilogridViewer(_kilogrid, _data_list, this);
  _kilogrid_viewer->setMinimumWidth(800);
  _kilogrid_viewer->setMinimumHeight(400);
  connect(_kilogrid_viewer, SIGNAL(grid_selected(coordinate_t,coordinate_t,subcell_id_t)),
          this, SLOT(selected(coordinate_t, coordinate_t, subcell_id_t)));
  return _kilogrid_viewer;
}


void MainWindow::selected(coordinate_t x, coordinate_t y, subcell_id_t id)
{
  switch(_tool) {
    case tool_state_t::SUBCELL:
      put_subcell_data(x, y, id);
      break;
    case tool_state_t::CELL:
      put_cell_data(x, y, id);
      break;
    case tool_state_t::ROW:
      put_row_data(x, y, id);
      break;
    case tool_state_t::COLUMN:
      put_column_data(x, y, id);
      break;
    default:
      return;
  }
  _kilogrid_viewer->repaint();
}


bool MainWindow::put_subcell_data(coordinate_t x, coordinate_t y, subcell_id_t id)
{
  switch(_mode) {
    case mode_state_t::MODE_CLEAR:
      _kilogrid->clear_state(x, y, id);
      break;
    case mode_state_t::MODE_SET:
      auto index = _data_viewer->selectionModel()->selectedIndexes();
      if(!index.isEmpty()) {
        _kilogrid->set_state(x, y, id, _data_list->state(index.at(0).row()));
      } else {
        QMessageBox::critical(this, "Kilogrid Editor", "Select data from the list.");
        return false;
      }
      break;
  }
  return true;
}


bool MainWindow::put_cell_data(coordinate_t x, coordinate_t y, subcell_id_t)
{
  for(subcell_id_t sc = 0; sc < Cell::NUMBER_OF_SUBCELLS; ++sc) {
    if(!put_subcell_data(x, y, sc)) return false;
  }
  return true;
}


bool MainWindow::put_row_data(coordinate_t row, coordinate_t, subcell_id_t id)
{
  auto sc_column = Cell::subcell_column(id);
  for(coordinate_t y = 0; y < _kilogrid->max_y(); ++y) {
    for(subcell_id_t sc = 0; sc < Cell::NUMBER_OF_SUBCELLS; ++sc) {
      if(Cell::subcell_column(sc) != sc_column) continue;
      if(!put_subcell_data(row, y, sc)) return false;
    }
  }
  return true;
}


bool MainWindow::put_column_data(coordinate_t, coordinate_t column, subcell_id_t id)
{
  auto sc_row = Cell::subcell_row(id);
  for(coordinate_t x = 0; x < _kilogrid->max_x(); ++x) {
    for(subcell_id_t sc = 0; sc < Cell::NUMBER_OF_SUBCELLS; ++sc) {
      if(Cell::subcell_row(sc) != sc_row) continue;
      if(!put_subcell_data(x, column, sc)) return false;
    }
  }
  return true;
}