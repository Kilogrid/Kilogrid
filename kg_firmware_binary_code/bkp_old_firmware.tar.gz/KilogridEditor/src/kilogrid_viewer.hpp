#ifndef KILOGRIDVIEWER_HPP
#define KILOGRIDVIEWER_HPP

#include <QWidget>

#include "cell.hpp"


class Kilogrid;
class DataList;


class KilogridViewer : public QWidget
{
  Q_OBJECT

  using coordinate_t = typename Cell::coordinate_t;
  using subcell_id_t = typename Cell::subcell_id_t;

  public:
  KilogridViewer(const Kilogrid* kilogrid, const DataList* data_list, QWidget* parent = nullptr);


  signals:
  void grid_selected(coordinate_t x,
                     coordinate_t y,
                     subcell_id_t id);


  protected:
  void resizeEvent(QResizeEvent*) override;
  void paintEvent(QPaintEvent*) override;
  void mousePressEvent(QMouseEvent*) override;

  private:
  const Kilogrid* _kilogrid;
  const DataList* _data_list;
};

#endif // KILOGRIDVIEWER_HPP