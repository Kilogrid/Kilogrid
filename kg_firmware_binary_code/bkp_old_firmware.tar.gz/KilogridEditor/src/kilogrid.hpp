#ifndef KILOGRID_HPP
#define KILOGRID_HPP

#include <QtGlobal>

#include "cell.hpp"


class QFile;


class Kilogrid
{
  using coordinate_t    = typename Cell::coordinate_t;
  using subcell_id_t    = typename Cell::subcell_id_t;
  using subcell_state_t = typename Cell::subcell_state_t;

  public:
  static constexpr size_t DEFAULT_X = 10;
  static constexpr size_t DEFAULT_Y = 20;

  Kilogrid();
  Kilogrid(size_t mx, size_t my);
  Kilogrid(const Kilogrid&);
  Kilogrid(Kilogrid&&) noexcept;

  ~Kilogrid() noexcept;

  Kilogrid& operator=(const Kilogrid&) noexcept;
  Kilogrid& operator=(Kilogrid&&) noexcept;

  void resize(size_t mx, size_t my);

  bool set_state(coordinate_t x, coordinate_t y, subcell_id_t subcell_id, subcell_state_t state)
  {
    return _cells[index(x, y)].set_state(subcell_id, state);
  }

  void clear_state(coordinate_t x, coordinate_t y, subcell_id_t id)
  {
    _cells[index(x, y)].clear_state(id);
  }

  const Cell& cell(coordinate_t x, coordinate_t y) const noexcept
  {
    return _cells[index(x, y)];
  }

  size_t max_x() const noexcept
  {
    return _max_x;
  }

  size_t max_y() const noexcept
  {
    return _max_y;
  }

  void invert_x();
  void invert_y();

  void clear();

  bool load_from(QFile& file);
  bool export_to(QFile& file);


  private:
  size_t index(size_t x, size_t y) const noexcept
  {
    Q_ASSERT(x < _max_x);
    Q_ASSERT(y < _max_y);
    return x * _max_y + y;
  }

  void set_cell(const Cell& cell)
  {
    _cells[index(cell.x(), cell.y())] = cell;
  }

  void swap(Kilogrid& other);

  private:
  size_t _max_x, _max_y;
  Cell*  _cells;
};

#endif // KILOGRID_HPP