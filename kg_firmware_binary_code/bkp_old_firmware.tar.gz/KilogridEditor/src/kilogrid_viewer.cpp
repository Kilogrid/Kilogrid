#include "kilogrid_viewer.hpp"

#include <algorithm>
#include <iostream>

#include <QPainter>
#include <QWheelEvent>
#include <QStaticText>

#include "kilogrid.hpp"
#include "data_list.hpp"
#include "main_window.hpp"


namespace {
  constexpr int LEFT_MARGIN = 50, RIGHT_MARGIN = 10;
  constexpr int TOP_MARGIN = 50, BOTTOM_MARGIN = 10;
  constexpr int INNER_MARGIN = 2;

  const QColor BACKGROUND_COLOR    = QColor::fromRgb(220, 220, 220);
  const QColor CELL_FRAME_COLOR    = QColor::fromRgb(0, 0, 0);
  const QColor SUBCELL_FRAME_COLOR = QColor::fromRgb(140, 140, 140);

  struct GridInfo {
    QRect GRID_BOUNDS;
    int XMAX;
    int YMAX;
    int SUBCELL_SIZE;
    int CELL_SIZE;
  };

  auto get_current_grid_info(const KilogridViewer* viewer, const Kilogrid* kilogrid) -> const GridInfo
  {
    GridInfo ret;
    const int width  = viewer->width() - (LEFT_MARGIN + RIGHT_MARGIN);
    const int height = viewer->height() - (TOP_MARGIN + BOTTOM_MARGIN);
    ret.XMAX         = kilogrid->max_x();
    ret.YMAX         = kilogrid->max_y();
    ret.SUBCELL_SIZE = std::min(width/ret.YMAX, height/ret.XMAX) / 2;
    ret.CELL_SIZE    = ret.SUBCELL_SIZE * 2;
    ret.GRID_BOUNDS  = QRect(LEFT_MARGIN, TOP_MARGIN,
                             ret.CELL_SIZE * ret.YMAX, ret.CELL_SIZE * ret.XMAX);
    return ret;
  }
}


KilogridViewer::KilogridViewer(const Kilogrid* kilogrid, const DataList* data_list, QWidget* parent)
  : QWidget(parent),
    _kilogrid(kilogrid),
    _data_list(data_list)
{
  setAcceptDrops(true);
  QPalette palette(QWidget::palette());
  palette.setColor(backgroundRole(), BACKGROUND_COLOR);
  setAutoFillBackground(true);
  setPalette(palette);
}


void KilogridViewer::paintEvent(QPaintEvent*)
{
  QPainter painter(this);
  painter.setRenderHint(QPainter::Antialiasing);

  const auto HINT = get_current_grid_info(this, _kilogrid);

  // Draw labels
  painter.drawStaticText(
        HINT.GRID_BOUNDS.left() - 2*HINT.SUBCELL_SIZE,
        HINT.GRID_BOUNDS.height() / 2 + HINT.GRID_BOUNDS.top(),
        QString("X"));
  for(auto x = 0, current_X = HINT.GRID_BOUNDS.top(); x < HINT.XMAX; ++x, current_X += HINT.CELL_SIZE) {
    painter.drawStaticText(
          HINT.GRID_BOUNDS.left() - HINT.SUBCELL_SIZE,
          current_X + HINT.SUBCELL_SIZE,
          QString("%1").arg(x+1,2));
  }
  painter.drawStaticText(
        HINT.GRID_BOUNDS.width()/2 + HINT.GRID_BOUNDS.left(),
        HINT.GRID_BOUNDS.top() - HINT.CELL_SIZE,
        QString("Y"));
  for(auto y = 0; y < HINT.YMAX; ++y) {
    painter.drawStaticText(
              y * HINT.CELL_SIZE + INNER_MARGIN + HINT.GRID_BOUNDS.left(),
              HINT.GRID_BOUNDS.top() - HINT.SUBCELL_SIZE,//INNER_MARGIN,
              QString("%1").arg(y+1,2));
  }

  // Draw subcell frames
  painter.setPen(SUBCELL_FRAME_COLOR);
  for(auto x = 0, current_X = HINT.GRID_BOUNDS.top() + HINT.SUBCELL_SIZE; x < HINT.XMAX; ++x, current_X += HINT.CELL_SIZE) {
    painter.drawLine(HINT.GRID_BOUNDS.left(), current_X, HINT.GRID_BOUNDS.right(), current_X);
  }
  for(auto y = 0, current_Y = HINT.GRID_BOUNDS.left() + HINT.SUBCELL_SIZE; y < HINT.YMAX; ++y, current_Y += HINT.CELL_SIZE) {
    painter.drawLine(current_Y, HINT.GRID_BOUNDS.top(), current_Y, HINT.GRID_BOUNDS.bottom());
  }

  // Draw cell frames
  painter.setPen(CELL_FRAME_COLOR);
  for(auto x = 0, current_X = HINT.GRID_BOUNDS.top(); x <= HINT.XMAX; ++x, current_X += HINT.CELL_SIZE) {
    painter.drawLine(HINT.GRID_BOUNDS.left(), current_X, HINT.GRID_BOUNDS.right(), current_X);
  }
  for(auto y = 0, current_Y = HINT.GRID_BOUNDS.left(); y <= HINT.YMAX; ++y, current_Y += HINT.CELL_SIZE) {
    painter.drawLine(current_Y, HINT.GRID_BOUNDS.top(), current_Y, HINT.GRID_BOUNDS.bottom());
  }


  // Draw subcell states
  const int sc_rect = HINT.SUBCELL_SIZE - 2 * INNER_MARGIN;
  for(auto y = 0, current_Y = HINT.GRID_BOUNDS.left(); y < HINT.YMAX; ++y, current_Y += HINT.CELL_SIZE) {
    for(auto x = 0, current_X = HINT.GRID_BOUNDS.top(); x < HINT.XMAX; ++x, current_X += HINT.CELL_SIZE) {

      const auto& cell = _kilogrid->cell(x, y);

      for(auto sc = 0u; sc < Cell::NUMBER_OF_SUBCELLS; ++sc) {

        if(!has_data(cell, sc)) continue;

        auto color = _data_list->get_state_color(cell.state(sc));
        switch(sc) {
          case 0:
            painter.fillRect(
                  current_Y + HINT.SUBCELL_SIZE + INNER_MARGIN, current_X + INNER_MARGIN,
                  sc_rect, sc_rect, color);
            break;
          case 1:
            painter.fillRect(
                  current_Y + HINT.SUBCELL_SIZE + INNER_MARGIN, current_X + HINT.SUBCELL_SIZE + INNER_MARGIN,
                  sc_rect, sc_rect, color);
            break;
          case 2:
            painter.fillRect(
                  current_Y + INNER_MARGIN, current_X + INNER_MARGIN,
                  sc_rect, sc_rect, color);
            break;
          case 3:
            painter.fillRect(
                  current_Y + INNER_MARGIN, current_X + HINT.SUBCELL_SIZE + INNER_MARGIN,
                  sc_rect, sc_rect, color);
            break;
        }
      }
    }
  }
}


void KilogridViewer::resizeEvent(QResizeEvent*)
{
  repaint();
}


void KilogridViewer::mousePressEvent(QMouseEvent* event)
{
  const auto H = get_current_grid_info(this, _kilogrid);

  int mx = event->x();
  int my = event->y();
  if(!H.GRID_BOUNDS.contains(mx, my)) return;


  mx -= H.GRID_BOUNDS.left();
  my -= H.GRID_BOUNDS.top();
  int yr = ((mx / H.SUBCELL_SIZE) & 0x01) ^ 0x01, xr = (my / H.SUBCELL_SIZE) & 0x01;

  coordinate_t y = mx / H.CELL_SIZE, x = my / H.CELL_SIZE;
  subcell_id_t id = (yr << 1) | xr;

  emit grid_selected(x, y, id);
}