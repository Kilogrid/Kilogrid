#ifndef CELL_HPP
#define CELL_HPP

#include <cstddef>
#include <cstdint>

#include <QString>

#include "configurationitem.h"
extern "C" {
#include "conversion.h"
}


/**
 * @brief The Cell class
 */
class Cell {

  public:
  using subcell_id_t    = _kilogrid_subcell_id_t;
  using subcell_state_t = _kilogrid_subcell_state_t;
  using data_t          = _kilogrid_cell_data_t;
  using coordinate_t    = uint8_t;


  // Limit of data
  static constexpr data_t DATA_LIMIT = CONFIGURATION_DATA_SIZE;  // Defined in KiloGUI

  // Size
  static constexpr size_t NUMBER_OF_SUBCELL_ROWS    = 2;
  static constexpr size_t NUMBER_OF_SUBCELL_COLUMNS = 2;
  static constexpr size_t NUMBER_OF_SUBCELLS        = NUMBER_OF_SUBCELL_ROWS * NUMBER_OF_SUBCELL_COLUMNS;


  static bool is_valid_data(subcell_id_t id, subcell_state_t state);

  static size_t subcell_row(subcell_id_t id) {
    constexpr size_t ROW_MASK = 0x02;
    return (id & ROW_MASK) >> 1;
  }

  static size_t subcell_column(subcell_id_t id)
  {
    constexpr size_t COLUMN_MASK = 0x01;
    return (id & COLUMN_MASK);
  }


  Cell();
  Cell(coordinate_t x, coordinate_t y);

  subcell_state_t state(subcell_id_t id) const noexcept
  {
    return _subcell_states[id];
  }

  coordinate_t x() const noexcept
  {
    return _x;
  }

  coordinate_t y() const noexcept
  {
    return _y;
  }

  void clear_state(subcell_id_t id);

  bool set_state(subcell_id_t id, subcell_state_t state)
  {
    return is_valid_data(id, state) ? (_subcell_states[id] = state, true) : false;
  }

  void swap(Cell& cell);

  void invert_x();
  void invert_y();

  private:
  coordinate_t    _x, _y;
  subcell_state_t _subcell_states[NUMBER_OF_SUBCELLS];
};


/**
 * @brief   Check subcell state
 * @param   cell Target cell
 * @param   id   Target subcell
 * @return  true if target subcell state is not default
 */
inline bool has_data(const Cell& cell, Cell::subcell_id_t id)
{
  return Cell::is_valid_data(id, cell.state(id));
}

bool has_any_data(const Cell& cell);

#endif // CELL_HPP