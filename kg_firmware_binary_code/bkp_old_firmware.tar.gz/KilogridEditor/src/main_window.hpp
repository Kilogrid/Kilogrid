#ifndef MAINWINDOW_HPP
#define MAINWINDOW_HPP

#include <QMainWindow>
#include "cell.hpp"


class QGroupBox;
class QRadioButton;
class QPushButton;
class QTreeView;
class QErrorMessage;

class Kilogrid;
class DataList;
class KilogridViewer;


class MainWindow : public QMainWindow
{
  Q_OBJECT

  using coordinate_t = typename Cell::coordinate_t;
  using subcell_id_t = typename Cell::subcell_id_t;

  enum struct mode_state_t {
    MODE_SET, MODE_CLEAR
  };

  enum struct tool_state_t {
    NONE, SUBCELL, CELL, ROW, COLUMN
  };

  friend class Editor;

  public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();

  void initialize();


  /**** Menu bar ****/
  private:
  QMenuBar*       createMenuBar();

  private slots:
  void menu_import();
  void menu_export();
  void edit_invert_x();
  void edit_invert_y();


  /**** Mode ****/
  private:
  QRadioButton *_mode_set, *_mode_clear;
  mode_state_t _mode;

  QGroupBox*      createModeGroup();

  private slots:
  void switch_mode_set();
  void switch_mode_clear();


  /**** Tools ****/
  private:
  QPushButton *_tool_subcell, *_tool_cell, *_tool_row, *_tool_column;
  QPushButton *_tool_all, *_tool_random_empty, *_tool_random_all;
  tool_state_t _tool;

  QGroupBox*      createToolGroup();

  private slots:
  void select_subcell(bool);
  void select_row(bool);
  void select_column(bool);
  void select_cell(bool);
  void select_all();
  void select_random_empty();
  void select_random_all();


  /**** Data ****/
  private:
  QGroupBox    *_data_group;
  DataList     *_data_list;
  QTreeView    *_data_viewer;
  QPushButton  *_data_add, *_data_modify, *_data_clear;

  QGroupBox*      createDataGroup();

  private slots:
  void data_add();
  void data_modify();
  void data_clear();


  /**** Edit via KilogridViewer ****/
  private:
  Kilogrid       *_kilogrid;
  KilogridViewer *_kilogrid_viewer;

  KilogridViewer* createKilogridViewer();
  bool put_subcell_data(coordinate_t x, coordinate_t y, subcell_id_t id);
  bool put_cell_data(coordinate_t x, coordinate_t y, subcell_id_t id);
  bool put_row_data(coordinate_t x, coordinate_t y, subcell_id_t id);
  bool put_column_data(coordinate_t x, coordinate_t y, subcell_id_t id);

  private slots:
  void selected(coordinate_t, coordinate_t, subcell_id_t);
};

#endif // MAINWINDOW_HPP