/** \file Cell_lib.h 
 *
 * @brief This file implements high level handling of CAN messages based on
 * their type. Commands or bootpages forwarded to the kilobots are
 * processed here. The two functions defined handle the cell initialization
 * and the starting of the cell as well.
 *
 * Initializing the cell means initializing all the peripherals:
 *  - serial
 *  - led driver
 *  - CAN
 *  - IR
 *
 * Starting the cell:
 *  - waiting for kilobot bootpages
 *  - transferring the bootpages to the kilobots once complete
 *  - calling user supplied setup, triggered by CAN_CELL_SETUP message
 *  - calling user supplied loop, triggered by CAN_CELL_RUN message 
 */

// TODO: credits to the harvard kilobot firmware version 2

#ifndef __CELL_LIB_H__
#define __CELL_LIB_H__

/**** INCLUDES ****/
#include <mcp2515.h>


/**** DEFINES ****/

// used by higher level functionalities (LEDs, IR, etc)
#define N_SUBCELLS							4 // cell's revision A contains 4 subcells
#define SUBCELL_LOWER_INDEX					0x00
#define SUBCELL_UPPER_INDEX					SUBCELL_LOWER_INDEX + (N_SUBCELLS - 1) // subcells are numbered from SUBCELL_LOWER_INDEX to SUBCELL_HIGHER_INDEX

/** Size of the buffer that holds configuration. */
#define CELL_CONFIGURATION_BUFFER_SIZE		48

typedef enum {
	CELL_EEPROM_X_COORD_ADDR = 0xB2,
	CELL_EEPROM_Y_COORD_ADDR,
	CELL_EEPROM_CALIB_RESTRICTED,
	CELL_EEPROM_CALIB_X_MIN,
	CELL_EEPROM_CALIB_X_MAX,
	CELL_EEPROM_CALIB_Y_MIN,
	CELL_EEPROM_CALIB_Y_MAX,
} cell_eeprom_address_t;

#define CAN_MESSAGE_BUFFER_SIZE				10 
#define MS_TO_TICKS(a)						(a / 32)							

/**** TYPEDEFS AND ENUMS ****/

typedef void (*AddressPointer_t)(void) __attribute__ ((noreturn));

/*
 *	@brief Enumerates all possible cell states used in the experiments.
 */
typedef enum{
	CELL_INIT = 0x00,

	/**
	 * @brief Triggered by receiving a CAN_CELL_IDLE message. Currently
	 * pulsing LEDs indicate this state.
	 */
	CELL_IDLE,

	/**
	 * @brief State after receiving the second part of a CAN_FORWARD_IR_MESSAGE
	 * message, transmits the message in IR_setup_message variable on all
	 * subcells.
	 */
	CELL_SETUP_KILOBOTS,

	/**
	 * @brief Cell is waiting for bootpages.
	 *
	 * Triggered by receiving a CAN_KILO_BOOTPAGE_NUMBER CAN message.
	 */
	CELL_WAITING_FOR_KILOBOT_BOOTPAGE,

	/**
	 * @brief Sends the current bootpage in 6 byte chunks to the kilobots.
	 *
	 * Triggered after receiving the last bootpage on the CAN bus.
	 */
	CELL_BOOTLOADING_KILOBOTS,

	/**
	 * @brief Received information about the configuration and is waiting for the data.
	 *
	 * Triggered by receiving a CAN_CELL_CONFIG_SIZE message.
	 */
	CELL_WAITING_FOR_CONFIGURATION_DATA,

	/**
	 * @brief State entered when the cell is about to start and sets up all
	 * user variables before start (via callind the user supplied setup 
	 * funcion).
	 * 
	 * Triggered by receiving a CAN_CELL_SETUP message.
	 */
	CELL_SETUP,

	/**
	 * @brief Calls the user supplied loop function.
	 *
	 * Triggered by receiving a CAN_CELL_RUN message.
	 */
    CELL_RUNNING
} cell_state_t;

/**
 *	@brief Enumerates all subcells addresses of the cell. 
 *  The addresses relate to their position in the MUXes and LED driver positions. 
 */
typedef enum{
	SC00 = SUBCELL_LOWER_INDEX,
	SC01 = SUBCELL_LOWER_INDEX + 1,
	SC02 = SUBCELL_LOWER_INDEX + 2,
	SC03 = SUBCELL_LOWER_INDEX + 3
} subcell_num_t;

/** 
 * 	@brief States that a subcell can take during a Kilogrid experiment. This list is to be expanded. 
 *	@note  If you directly add new states to this list, you should insert them in front of the sentry.
 *	@code
 *	// how to add user-defined state without conflicts
 *	#define USER_DEFINED_SUBCELL_STATE  SUBCELL_STATE_PREDEFINED_COUNT + 1
 *	@endcode
 */
#if defined(CUSTOMIZABLE_SUBCELL_STATES_T)
typedef uint8_t subcell_states_t;  // [suggestion] it should be a type, not be enum, for extensibility
#else
typedef enum{
	SUBCELL_STATE_NONE = 0x00,
	SUBCELL_STATE_WALL,
	SUBCELL_STATE_HAS_SEED,
	SUBCELL_STATE_PLANT,
	SUBCELL_STATE_PLANT_WET,
	SUBCELL_STATE_PLANT_DRY,
	SUBCELL_STATE_PREDEFINED_COUNT, ///< [sentry] defined to avoid conflict between pre-defined and user-defined
	SUBCELL_STATE_WAIT_FOR_CONFIRMATION
} subcell_states_t;
#endif

/**** VARIABLES ****/

/**
 * Unique id of the subcell, used by the entire cell lib, and made accessible
 * to the user.
 */
extern volatile uint16_t cell_uid;
extern volatile uint8_t cell_uid_x_coord; ///< Debug only
extern volatile uint8_t cell_uid_y_coord; ///< Debug only

/**
 * @brief Can be used for timing purposes, increased every 1/32th of a second.
 * CellIR.h has TICKS_PER_SEC and SEC_TO_TICKS(a) macros to help handling
 * this.
 *
 * @note Updated in CellIR.c: ISR(TIMER0_COMPA_vect). Used for IR tx timing.
 */
extern volatile uint32_t cell_ticks;

/** Size of configuration data in bytes. */
extern volatile uint8_t configuration_size;

/** Configuration data. */
extern volatile uint8_t configuration[CELL_CONFIGURATION_BUFFER_SIZE];


/**** MACROS ****/

#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
extern "C" {
#endif

/**** PROTOTYPES ****/

/** Debug-only */
void init_serial(void);

/**
 * @brief Initialize cell hardware.
 *
 * This function initializes all hardware of the cell. This includes setting hardware timers,
 * configuring ports, setting up analog-to-digital converters,
 * registering system interrupts and the initializing the messaging
 * subsystem.
 * 
 * It is recommended that you call this function as early as possible
 * inside the `main` function of your program.
 */
void cell_init(void);

/**
 * @brief Start cell event loop.
 *
 * This function receives two parameters. The first parameter @p setup
 * is a function which will be called once to perform any initialization
 * required by your user program. The second parameter @p loop is a
 * function that will be called repeatedly to perform any computations
 * required by your user program.
 *
 * Using the overhead controller it is possible to interrupt the event
 * loop to trigger events such as program start/resume, program pause,
 * and program restart.
 *
 * @param setup Put your setup code here, it will be called in a loop
 					the configuration for the cell (if any) is in the
 					configuration variable, the size of the configuration
 					data is configuration_size bytes. If configuration_size
 					is 0 it means that no configuration data was received.

 * @param loop  Put your main code here, will be run repeatedly.
 *
 * @code
 *
 * uint32_t counter;
 *
 * void setup() {
 *    counter = 0;
 * }
 *
 * void loop() {
 *    counter++;
 * }
 *
 * int main() {
 *   cell_init();
 *   cell_start(setup, loop);
 *   return 0;
 * }
 * @endcode
 */
void cell_start(void (*setup)(void), void (*loop)(void));
void cell_enable_autostart();

CAN_message_t* next_CAN_message();

#ifdef __cplusplus
}  // extern "C"
#endif

#endif //__CELL_LIB_H__
