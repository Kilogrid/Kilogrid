/** \file CellLEDs.h */

#ifndef __CELLLEDS_H__
#define __CELLLEDS_H__

#include "stdint.h"
#include "Cell_lib.h"

/**** DEFINES ****/
#define PCA9635_I2C_ADDR 		0x15 ///< Address of the LED driver
#define LED_UPPER_REG_LIMIT		0x0D ///< LED11 PWM signal register address is 0x0D	
#define LED_LOWER_REG_LIMIT		0x02 ///< LED0 PWM signal register address 0x02
#define N_LED					12   ///< Number of LED signals on the board
#define LED_MAX_BRIGHTNESS		0xF0 ///< Arbitrary - not maximum, but high enough

/**** MACROS ****/

/**
 * @brief Macro that returns the LED driver register number that corresponds to an LED of subcell
 * s is the subcell number, and c the RGB color component (either R, G or B).
 * This macro assumes that the LEDs are connected to the LED driver in this way: R,G,B,R,G,B,...
 *
 * @param s  subcell identifier
 * @param c  RGB color component
 */
#define GET_LED_REG_ADDR(s, c)	s*3 + c	+ LED_LOWER_REG_LIMIT

/**** TYPEDEFS AND ENUMS ****/

/**
 * @brief Color components of every color based on their RGB value.
 * The LSB indicates the R component, and the MSB the B component.
 */
typedef enum{
	RED =		0b001,
	GREEN =		0b010,
	BLUE =		0b100,
	YELLOW =	0b011,
	CYAN =		0b110,
	MAGENTA =	0b101,
	WHITE =		0b111,
	LED_OFF =	0b000
} color_t;

/** @brief Brightness constants. */
typedef enum{
	LOW = 0x05,
	MEDIUM = 0x20,
	HIGH = LED_MAX_BRIGHTNESS
} brightness_t;

/**** PROTOTYPES ****/

void init_CellLEDs(void);
void set_LED(subcell_num_t, color_t, brightness_t); // TODO invert names? rename? (could not overload function)
void set_LED2(subcell_num_t, color_t);
void set_all_LEDs(color_t, brightness_t);
void set_all_LEDs2(color_t);

#endif // CELLLEDS_H