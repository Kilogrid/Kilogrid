/** \file platform.h
 *
 * @brief By being included by other files, this file allows the different parts of the Kilobot system\
 * to share the same library files through #ifdef/#ifndef directives.
*/

#ifndef __PLATFORM_H__
#define __PLATFORM_H__

//#define KILOGUI
//#define DISPATCHER
#define CELL
//#define KILOBOT

#endif // __PLATFORM_H__

