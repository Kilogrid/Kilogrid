// TODO credits to kilolib.c
// TODO incorporate IR messaging part in CellIR.c, .h and CAN.h, c?
// TODO cell_state change detection mechanism for a single-time execution of code for each state (= after each state change)

/**** INCLUDES ****/
#include <stdlib.h>						// for rand()
#include <avr/wdt.h>					// watch dog timer
#include <avr/interrupt.h>
#include <avr/eeprom.h>					// read eeprom values
#include <stdlib.h>						// for rand()
#include <util/delay.h>					// delay macros

#include "debug.h"
#include "rand.h"
#include "ADC.h"
#include "IO.h"
#include "CAN.h"
#include "message.h"
#include "message_crc.h"

#include "kilogrid.h"
#include "CellIR.h"
#include "Cell_lib.h"
#include "CellLEDs.h"
#include "bootldr.h"

#include <ringbuffer.h>

#include <string.h>						// for memcpy

//#define VERBOSE_ON
//#define DUMP_BOOTPAGE_ON
//#define TESTS							// used for the cell to respond to the old KiloGUI application commands (to be removed)

//#define ITF								// Intensive Testing Firmware: the times to light up an LED at boot are increased for testing purposes

/**** VARIABLE DECLARATIONS ****/

volatile uint8_t cell_uid_x_coord;				// x coordinate of the cell in the grid (determined at programming time, stored in EEPROM) - LSBs of cell_uid
volatile uint8_t cell_uid_y_coord;				// y coordinate of the cell in the grid (determined at programming time, stored in EEPROM) - MSBs of cell_uid
volatile uint16_t cell_uid;						// cell identifier
volatile cell_state_t cell_state;		// internal state of the cell

volatile uint8_t cell_calib_restricted;
volatile uint8_t cell_calib_x_min;
volatile uint8_t cell_calib_x_max;
volatile uint8_t cell_calib_y_min;
volatile uint8_t cell_calib_y_max;
	
volatile color_t c;						// color of the cell during configuration

CAN_message_t CAN_message_rx;			// store received message
CAN_message_t CAN_message_bootpage;		// CAN message that stores bootpage messages

/** @brief CAN messages buffer that contains the CAN user messages to be sent. */
RB_create(CAN_message_tx_buffer, CAN_message_t, CAN_MESSAGE_BUFFER_SIZE);

/**
 * @brief Stores received message until process_CAN_message transfers it into
 * either CAN_message_rx or CAN_message_bootpage depending on the type if the
 * message.
 */
CAN_message_t CAN_message_rx_buffer;	// store received message from interrupt

/**
 * @brief Type of the received CAN message. The switch in process_CAN_message is
 * done based on this value.
 */
volatile CAN_message_type_t CAN_msg_type;
volatile uint8_t fCAN_debug_rx;

/**
 * @brief Stores the number of bootpages contained in the bootloader.
 * Triggered by a CAN_FORWARD_IR_MESSAGE IR message with IR message type
 * BOOTPGM_SIZE.
 */
volatile uint8_t page_total;

/**
 * @brief Index of current bootpage we are receiving
 */
volatile uint8_t page_count = 0;

/**
 * @brief Address of current bootpage, sent in a CAN_KILO_BOOTPAGE_NUMBER CAN message.
 */
volatile uint8_t page_address;

/**
 * @brief Position of the next data byte in the current_bootpage.data array.
 */
volatile uint8_t page_offset;

/**
 * @brief Indicates if current bootpage was sent (send only once).
 */
volatile uint8_t bootpage_sent;

/**
 * @brief Indicates whether a received bootpage was faulty, should not be sent
 * to the kilobot.
 */
volatile uint8_t bootpage_faulty;

/**
 * @brief Used to send the Kilobot program with the different subcells, and switch from one subcell to the other after sending the whole program
 */
volatile subcell_num_t bootloading_current_subcell = SC00;

/**
 * @brief Bootpage data is loaded into this buffer from the CAN messages.
 */
volatile bootpage_data_bytes_t current_bootpage;

volatile uint8_t previous_CAN_msg_number;

/**
 * @brief Struct that carries the message to send to the kilobots during the
 * setup phase, used by CAN_FORWARD_IR_MESSAGE of process_CAN_message.
 */
IR_message_t IR_setup_message;

volatile uint8_t received_setup;

/** @brief Brightness of the LEDs in idle state. */
volatile uint8_t brightness_idle = 0;

/** @brief Indicates if the brightness is decreasing (-1) or increasing (1). */
volatile int8_t brightness_dir;

/** @brief 1 if not all configuration data was received. */
volatile uint8_t configuration_faulty;

/** @brief Value from 1 to 8: number of CAN messages with configuration data. */
volatile uint8_t configuration_total;

/** @brief ID of the currently received configuration segment. */
volatile uint8_t configuration_msg_counter;

/** @brief Size of configuration data in bytes. */
volatile uint8_t configuration_size;

/** @brief Configuration data. */
volatile uint8_t configuration[CELL_CONFIGURATION_BUFFER_SIZE];

/** @brief To execute code once before running the loop() variable */
volatile uint8_t has_started;

/** @brief To jump directly to the user program without the user intervention */
volatile uint8_t cell_autostart = 0;

volatile uint8_t messages_to_send = 0;

volatile uint8_t sending_tracking_data = 0;

volatile uint8_t sent_tracking_header = 0;

kilogrid_address_t CAN_address_to_dispatcher;

volatile uint8_t poll_debug_led_toggle = 0;

CAN_message_t poll_response_message;

/**** FUNCTION POINTERS DECLARATIONS ****/

/** @brief Empty dummy callback function for CAN rx handling */
void CAN_message_rx_dummy(CAN_message_t *m) { }

/** @brief Empty dummy callback function for IR rx handling */
void IR_message_rx_dummy(IR_message_t *m, subcell_num_t sc, distance_measurement_t *d, uint8_t CRC_error) { ; }

/** @brief Empty dummy callback function for IR tx handling */
void IR_message_tx_success_dummy(subcell_num_t sc) {;}

/**
 *  @brief Empty dummy callback for the CAN tx success handling.
 */
void CAN_message_tx_success_dummy(){}

/**
 * @brief CAN message received callback.
 * Registering an empty dummy is necessary before receiving CAN messages.
 * Otherwise CAN messages would make the program fail when initializing.
 *
 * @note It is forbidden to use blocking calls in this function, as well as the CellLEDs.c functionalities (too slow).
 */
CAN_message_rx_t cell_CAN_message_rx = CAN_message_rx_dummy;

/**
 * @brief CAN message tx success callback.
 *
 * @note It is forbidden to use blocking calls in this function, as well as the CellLEDs.c functionalities (too slow).
 */
CAN_message_tx_success_t cell_CAN_message_tx_success = CAN_message_tx_success_dummy;

/**
 * @brief IR message received callback.
 * Registering an empty dummy is necessary before receiving IR messages.
 * Otherwise IR messages would make the program fail when initializing.
 */
IR_message_rx_t cell_IR_message_rx = IR_message_rx_dummy;

/**
 * @brief IR message successfully sent callback.
 * Registering an empty dummy is necessary before sending IR messages.
 * Otherwise IR messages would make the program fail.
 */
IR_message_tx_success_t cell_IR_message_tx_success = IR_message_tx_success_dummy;

/**** PRIVATE FUNCTIONS ****/

/**
 *  @brief Used internally to send the next message on the CAN message tx buffer. The function is called by the main while(1) loop (see cell_start() function) at each iteration (best effort). It is the duty of the user to place CAN messages on the buffer through the add_CAN_message_to_buffer() function.
 *  
 *  @return 1 if successful.
 *  @see add_CAN_message_to_buffer
 *  
 */
uint8_t send_next_CAN_message(){
	if(!RB_empty(CAN_message_tx_buffer)){
		CAN_message_tx(&RB_front(CAN_message_tx_buffer), CAN_address_to_dispatcher);
		return 1;
	}
	return 0;
}

void CAN_message_sent(){
	// remove front element of the buffer
}

/**
 * @brief Initialize the UART for data logging through serial. This function assumes a F_CPU clock of 8 MHz.
 *
 */
void init_serial(void){
	SET_AS_OUTPUT(TXD);
	SET_AS_INPUT(RXD); 
	UBRR0 = 1; //256000 baud
	UCSR0A = 0;
	UCSR0B |= (1 << TXEN0);
	UCSR0C |= (1 << UCSZ01) | (1 << UCSZ00);
}

/**
 * @brief Function that makes the program jump directly to the bootloader section
 * of the FLASH (NRWW region).
 */
void goto_bootloader(){
	//eeprom_write_byte(EEPROM_VALID_APPLICATION_BIT_ADDR, 0x00); // invalidate current application in FLASH
	while(!eeprom_is_ready());	
	
/*	cli();*/
	
	MCUCR = (1<<IVCE);
	MCUCR = (1<<IVSEL);
	
	EIMSK = 0; PCICR = 0; SPCR = 0; ACSR = 0; EECR = 0; ADCSRA = 0;    //disable A/D converter
	TIMSK0 = 0; TIMSK1 = 0; TIMSK2 = 0; TWCR = 0;         //disable timers
	
	asm volatile ("jmp 0x7000"); // jump to bootloader (NRWW) section
}

/**
 * @brief Send a message to be sent on subcell number "sc" without delay.
 *
 * @param	m	Message to send.
 * @param	sc	Identifier of the subcell to send the message from.
 */
void send_IR_message(IR_message_t *m, subcell_num_t sc){
	cli();
	m->crc = message_crc(m); // compute message CRC
	SELECT_IR_TRANSMITTER(sc);
	message_send(m);
	sei();
}


/**
 * @brief Process CAN messages before calling the user callback function.
 * This allows CAN messages to be filtered, to restrict the access of the user.
 * By default, all CAN messages are transferred to the user, except when the CAN message is identified as a special type of message (CAN_message_type_t)
 * to unnecessary CAN messages received.
 * This function takes the CAN message buffer and saves it before any operation on the current CAN message. 
 * It has been defined as an "inline" function to avoid the overhead of function calls when called by the CAN ISR.
 *
 * Unknown message types will be handled by cell_CAN_message_rx.
 * 
 * @note It is forbidden to use blocking calls in this function, as well as the CellLEDs.c functionalities (too slow).
 */
inline void process_CAN_message() {
	uint8_t i, j = 0;
	
	CAN_msg_type = CAN_message_rx_buffer.data[0];
	uint8_t current_CAN_msg_number = CAN_message_rx_buffer.data[1];
						
	// transfer the content of the CAN msg buffer into the CAN_message struct to avoid race conditions
	if(CAN_msg_type == CAN_KILO_BOOTPAGE){
		CAN_message_bootpage = CAN_message_rx_buffer;
	}
	else{
		CAN_message_rx = CAN_message_rx_buffer;
	}
				
	switch(CAN_msg_type){
							
		case CAN_FORWARD_IR_MESSAGE_STOP:
							
			init_IR_message(&IR_setup_message);
							
			disable_IR_tx(SC00);
			disable_IR_tx(SC01);
			disable_IR_tx(SC02);
			disable_IR_tx(SC03);
							
			//set_all_LEDs2(LED_OFF); // FORBIDDEN
			
			cell_state = CELL_IDLE;
							
			break;
			
		case CAN_KILO_BOOTPAGE_SIZE:
			page_total = CAN_message_rx.data[2]; // store the size of the current Kilobot program
			break;
							
		case CAN_KILO_BOOTPAGE:
			// bootpage is faulty if the sequence number is not contiguous
			if(current_CAN_msg_number != 0
				&& current_CAN_msg_number != (previous_CAN_msg_number+1))
				{
					bootpage_faulty = 1;
				}
			
			// if bootpage is faulty then drop the rest of the bootpage
			if(bootpage_faulty) {
				break;
			}
			
			// current_CAN_msg_number is the bootpage data offset, in bytes
			page_offset = (current_CAN_msg_number * 6);
			
			if(current_CAN_msg_number < (CAN_MESSAGES_PER_BOOTPAGE-1)){
				for(j = 0; j < 6; j++){
					current_bootpage.data[page_offset + j] = CAN_message_bootpage.data[2 + j];
				}
			}
			else if(current_CAN_msg_number == (CAN_MESSAGES_PER_BOOTPAGE-1)){ // if the message is the last CAN message of current bootpage: only copy the two remaining words (128 - 126 = 2 bytes)
				for(j = 0; j < 2; j++){
					current_bootpage.data[page_offset + j] = CAN_message_bootpage.data[2 + j];
				}
			}			
			
			if(current_CAN_msg_number == (CAN_MESSAGES_PER_BOOTPAGE-1)){ // bootpage reception complete
				page_count++;
				
				cell_state = CELL_BOOTLOADING_KILOBOTS; // switch to CELL_BOOTLOADING_KILOBOTS state to send the bootpage in the main loop
				
				bootpage_sent = 0;
				
			} // if bootpage received
			
			previous_CAN_msg_number = current_CAN_msg_number;

			break;
			
		case CAN_KILO_BOOTPAGE_NUMBER:
			bootpage_faulty = 0;
			previous_CAN_msg_number = 0;
			page_address = CAN_message_rx.data[2]; // store address of current bootpage
			cell_state = CELL_WAITING_FOR_KILOBOT_BOOTPAGE;
			break;			
							
		case CAN_FORWARD_IR_MESSAGE: // IR message to be forwarded: receive it and broadcast to every subcell				
			if(current_CAN_msg_number == 0){ // first part of the IR message
								
				// copy CAN message into IR message - TODO change this using mem copy
				// i points to the CAN message data byte
				// this step copies 6 bytes of overall 9 into the setup message data buffer
				for (i = 0; i < 6; i++) {
					IR_setup_message.data[i] = CAN_message_rx.data[i+2];
				}
								
			}
			else if(current_CAN_msg_number == 1){ // second part of the IR message
				// there are 6 bytes in the IR_setup_message.data buffer
				// remaining IR data bytes to copy from CAN message: 9 - (CAN_MESSAGE_SIZE - 2) = 3
				// start from byte 2 in the CAN message for 3 bytes and copy to the IR_setup_message.data buffer from byte 6
				for (i = 0; i < 3; i++){
					IR_setup_message.data[6+i] = CAN_message_rx.data[i+2];
				}
				// i is incremented and points to the last byte of the IR message, which is the type
				IR_setup_message.type = CAN_message_rx.data[i+2];

				// if this is a calibration message but we are not part of the calibration area, skip processing
				if(IR_setup_message.type == CALIB && cell_calib_restricted == 1) {
					if( cell_uid_y_coord < cell_calib_y_min ||
						cell_uid_y_coord > cell_calib_y_max ||
						cell_uid_x_coord < cell_calib_x_min ||
						cell_uid_x_coord > cell_calib_x_max) {
							return;
					}
				}

				cell_state = CELL_SETUP_KILOBOTS; // will enter the CELL_SETUP_KILOBOTS state after this ISR (ie. after receiving the entire IR message)
								
				// display color
				switch(IR_setup_message.type){
					case RESET:
						c = GREEN;
						break;
					case BOOT:
						c = BLUE;
						bootloading_current_subcell = SC00; // start bootloading on subcell SC00
						page_count = 0; // reset page count
						break;
					case BOOTPGM_PAGE:
						c = CYAN;
						break;
					case SLEEP:
						c = WHITE;
						break;
					case RUN:
						c = MAGENTA;
						break;
					case VOLTAGE:
						c = YELLOW;
						break;
									
					// NOTE (ATFER REV 812): THE CELL SHOULD NOT RECEIVE ANY CAN_FORWARD_IR_MESSAGE CONTAINING A BOOTPGM_SIZE IR MESSAGE TYPE (SENT AS A SEPARATE CAN MESSAGE AT THE BEGINNING OF THE BOOTLOADING PROCEDURE)
					case BOOTPGM_SIZE:
						c = CYAN;
						break;
									
					case CHARGE:
						c = RED;
						break;

					case CALIB:
					case GO_STRAIGHT:
					case TURN_LEFT:
					case TURN_RIGHT:
						c = YELLOW;
						break;

					default:
						c = LED_OFF;
						break;
				}
								
			}
							
			break;
							
		case CAN_CELL_BOOT:
			goto_bootloader();
			break;
			
		case CAN_CELL_IDLE:
			cell_state = CELL_IDLE;
			break;
			
		case CAN_CELL_SETUP:
			cell_state = CELL_SETUP;
			break;
			
		case CAN_CELL_RUN:
			cell_state = CELL_RUNNING;
			break;

		case CAN_CELL_CONFIG_SIZE:
			// size of the configuration data in bytes
			configuration_size = CAN_message_rx.data[2];

			// number of CAN messages
			configuration_total = CAN_message_rx.data[2] / 6;
			if(CAN_message_rx.data[2] % 6 != 0) {
				configuration_total += 1;
			}

			configuration_faulty = 0;
			configuration_msg_counter = 0;
			cell_state = CELL_WAITING_FOR_CONFIGURATION_DATA;
			c = RED;

			break;

		case CAN_CELL_CONFIG_TRANSFER:
			if(cell_state != CELL_WAITING_FOR_CONFIGURATION_DATA ||
			   configuration_faulty){
				return;
			}

			if(current_CAN_msg_number != configuration_msg_counter) {
				configuration_faulty = 1;
				return;
			}

			for(i = 0; i < 6; i++) {
				//multiple messages can address a cell, data is collated
				configuration[configuration_msg_counter*6 + i] = CAN_message_rx.data[i+2];
			}

			configuration_msg_counter += 1;

			if(current_CAN_msg_number == configuration_total-1) {
				received_setup = 0;
				c = GREEN;
				cell_state = CELL_SETUP;
			}
			break;
	
		case CAN_TRACKING_REQ:
			sending_tracking_data = 1;
			sent_tracking_header = 0;
			messages_to_send = RB_size(CAN_message_tx_buffer);
			break;
			
		default:
			cell_CAN_message_rx(&CAN_message_rx); // transfer CAN message to the user. The user can receive all other CAN messages.
			break;
	}
}

/**** FUNCTIONS DEFINITIONS ****/

void cell_init(void){

	cli(); // enter critical section - disable interrupts
	
	has_started = 0;
	received_setup = 0;
	
	cell_state = CELL_INIT;

	/* Peripherals */
	// disable watchdog
	//WDTCSR |= (1<<WDCE)|(1<<WDE); // re-enable if not working
	WDTCSR = 0;
		
	// Reset all MCU ports
	ports_off();
	
	cell_uid_x_coord = eeprom_read_byte((uint8_t *)CELL_EEPROM_X_COORD_ADDR); // read the x coordinate on the grid (LSB of cell_uid)
	cell_uid_y_coord = eeprom_read_byte((uint8_t *)CELL_EEPROM_Y_COORD_ADDR); // read the y coordinate on the grid (MSB of cell_uid)
	cell_uid = cell_uid_x_coord | ((uint16_t)cell_uid_y_coord << 8); // merge the two in the cell_uid variable

	cell_calib_restricted = eeprom_read_byte((uint8_t *)CELL_EEPROM_CALIB_RESTRICTED);
	cell_calib_x_min = eeprom_read_byte((uint8_t *)CELL_EEPROM_CALIB_X_MIN);
	cell_calib_x_max = eeprom_read_byte((uint8_t *)CELL_EEPROM_CALIB_X_MAX);
	cell_calib_y_min = eeprom_read_byte((uint8_t *)CELL_EEPROM_CALIB_Y_MIN);
	cell_calib_y_max = eeprom_read_byte((uint8_t *)CELL_EEPROM_CALIB_Y_MAX);

	// initialized reused address descriptor in the direction of the dispatcher
	CAN_address_to_dispatcher.x = cell_uid_x_coord;
	CAN_address_to_dispatcher.y = cell_uid_y_coord;
	CAN_address_to_dispatcher.type = ADDR_DISPATCHER;
	
	init_CAN_message(&poll_response_message);
	poll_response_message.data[0] = CAN_TRACKING_KILOBOT_START;
	
	RB_init(CAN_message_tx_buffer); // init CAN message tx buffer
	
	cell_CAN_message_tx_success = CAN_message_sent; // register function callback
		
	// Setup Analog Comparator (enable IR reception) and ADC (distance measurements)
	ACOMP_SETUP();
	ADC_SETUP();
	
	// Setup peripherals
	init_serial();
	init_CellLEDs();
	init_CellCAN(cell_uid_x_coord, cell_uid_y_coord);
	init_CellIR();

	/* Variables */
	//bootmsg = (bootmsg_t*)IR_setup_message.data; // bootmsg points now towards the data field of IR_setup_message struct
	//bootmsg->page_address = page_address; // store bootpage address
	//bootmsg->unused = 0;
	
	brightness_dir = 1; // increasing
	configuration_size = 0;
	
	#ifdef ITF
		// do not display animation. This will be part of the test routines in the main loop
		
		_delay_ms(10000); // waiting time before the test begins
		
		cell_state = CELL_RUNNING; // directly go to the main!
		
	#else
		// display animation
		for(uint8_t j = 0; j < 3; j++){ // repeat 3 times
			
			// light up all LEDs in sequence
			for(uint8_t i = 0; i < 4; i++){
				set_LED2(i, 1 << j);
				_delay_ms(50);
			}
			// switch off all LEDs in sequence
			for(uint8_t i = 0; i < 4; i++){
				set_LED2(i, LED_OFF);
				_delay_ms(50);
			}
		}
	#endif

	uint8_t i;
	for(i=0; i<CELL_CONFIGURATION_BUFFER_SIZE; i++) {
		configuration[i] = 0;
	}
	
	cprints("Cell initialized.");

	sei(); // exit critical section - enable interrupts
}

void cell_start(void (*setup)(void), void (*loop)(void)) {
	uint8_t i, j;
	
	#ifdef ITF // force setup() once before executing main loop
		setup();
	#endif
	
	/**** CELL MAIN LOOP AND INTERNAL STATE MACHINE ****/
	while(1){
		
		//#define ULTRA_VERBOSE_ON
		#ifdef ULTRA_VERBOSE_ON
			cprinti(cell_state);
		#endif
		
		switch(cell_state){
			case CELL_INIT:
				cell_state = CELL_IDLE; // initial state after cell initialization

				if(cell_autostart) {
					cell_state = CELL_SETUP;
				}
				break;
				
			case CELL_IDLE:
				_delay_ms(70);
				
				if(brightness_idle == 20){
					brightness_dir = -1;
				}
				else if(brightness_idle == 0){
					brightness_dir = 1;
				}
				
				brightness_idle += brightness_dir; 
				
				set_all_LEDs(WHITE, brightness_idle);
				
				break; // wait for commands to arrive
				
			case CELL_SETUP_KILOBOTS:
				
				send_IR_message(&IR_setup_message, SC00);
				send_IR_message(&IR_setup_message, SC01);
				send_IR_message(&IR_setup_message, SC02);
				send_IR_message(&IR_setup_message, SC03);	
				
				set_all_LEDs2(c); // display state
						
				break;
				
			case CELL_WAITING_FOR_KILOBOT_BOOTPAGE:
			case CELL_WAITING_FOR_CONFIGURATION_DATA:
				//set_all_LEDs2(CYAN);
				break;
				
			case CELL_BOOTLOADING_KILOBOTS:

				if(bootpage_sent == 0) {
								
					cli(); // enter critical section
					
					// tests
					#ifdef VERBOSE_ON
					// test: page_address == 0 at some point here?
					cprints("page_addr");
					cprinti(page_address);
					cprints(""); // line return
					#endif

					#ifdef DUMP_BOOTPAGE_ON
					for(i = 0; i < 128; i++){
						cprinti(current_bootpage.data[i]);
					}
					cprints("");
					cprints("");
					#endif

					// Before sending the program, the size of the program is sent to the Kilobot
					if(page_count == 1){ // the first bootpage has been received
						IR_setup_message.type = BOOTPGM_SIZE;
						IR_setup_message.data[0] = page_total;
						send_IR_message(&IR_setup_message, bootloading_current_subcell); // send IR message directly
						//set_LED2(bootloading_current_subcell, YELLOW); // signal the transmission of the program size
						set_all_LEDs2(LED_OFF);
					}
					
					// preparing IR messages
					IR_setup_message.type = BOOTPGM_PAGE;
					IR_setup_message.data[0] = page_address;
					
					/**** Send bootpage to Kilobot ****/
					for(i = 0; i < BOOTPAGE_SIZE; i += 6){
						IR_setup_message.data[1] = i / 2;
						// copy bootload message payload from current_bootpage data
						for(j = 0; j < 6; j++) {
							IR_setup_message.data[2 + j] = current_bootpage.data[i + j]; // copy bootpage data in IR message struct to be sent
						}
						send_IR_message(&IR_setup_message, bootloading_current_subcell); // send IR message directly
					}
					
					sei(); // exit critical section

					bootpage_sent = 1; // avoids sending the same bootpage twice
					
					if((page_address & 0x01) == 0){ // even bootpage number
						set_LED2(bootloading_current_subcell, BLUE);
					}
					else{
						set_LED2(bootloading_current_subcell, GREEN);
					}
					
					if(page_count == page_total){ // last bootpage received
						page_count = 0; // simply reset counter - will be set to 1 when receiving the first bootpage of the program again
						set_all_LEDs2(LED_OFF);
						bootloading_current_subcell = (bootloading_current_subcell + 1) % 4; // jump to the next subcell
					}					
				}

				break;
				
			case CELL_SETUP:
				if(!received_setup) {
					received_setup = 1;
					setup();
				}

				if(cell_autostart) {
					cell_state = CELL_RUNNING;
				}
				
				break;
				
			case CELL_RUNNING:
				if(!has_started){
					has_started = 1;
					// first, broadcast RUN message to the Kilobots for a little while (we assume that all robots are in reset mode already)
					IR_setup_message.type = RUN;
					set_all_LEDs2(MAGENTA);
					
					for(i = 0; i < 10; i++){
						send_IR_message(&IR_setup_message, SC00);
						send_IR_message(&IR_setup_message, SC01);
						send_IR_message(&IR_setup_message, SC02);
						send_IR_message(&IR_setup_message, SC03);
					}

					RB_init(CAN_message_tx_buffer); // throw away any previous messages to be sent
				}
			
				/**** EXECUTE USER PROGRAM ****/
				loop(); // execute main loop defined in the main
				break;
			default:
				break;
		}
		
		if(sending_tracking_data) {
			if(!sent_tracking_header) {
				/*
				if(poll_debug_led_toggle) {
					set_all_LEDs2(RED);
				}
				else {
					set_all_LEDs2(GREEN);
				}
				*/

				sent_tracking_header = 1;
				
				poll_response_message.data[0] = CAN_TRACKING_KILOBOT_START;
				poll_response_message.data[1] = messages_to_send;
				poll_response_message.header.length = 2;

				CAN_message_tx(&poll_response_message, CAN_address_to_dispatcher);
				_delay_ms(1);
			}
			
			if(messages_to_send > 0) {
				messages_to_send -= 1;
				
				send_next_CAN_message();
				RB_popfront(CAN_message_tx_buffer);
			}
			else {
				sending_tracking_data = 0;
				poll_debug_led_toggle = !poll_debug_led_toggle;
			}
		}
		
		// reset has_started flag if state is not equal to CELL_RUNNING
		if(cell_state != CELL_RUNNING){
			has_started = 0;
		}
		
		if(cell_state != CELL_IDLE){
			brightness_idle = 0; // resetting brightness for a better animation rendering (all cells look synchronized after a new command)
		}
	}
}

void cell_enable_autostart() {
	cell_autostart = 1;
}


inline CAN_message_t* next_CAN_message() {
	CAN_message_t* ret = NULL;

	if(!RB_full(CAN_message_tx_buffer)) {
		ret = &RB_back(CAN_message_tx_buffer);
		RB_pushback(CAN_message_tx_buffer); // move internal pointer to the next element
	}

	return ret;
}

/**
 * @brief Interrupt Service Routine for INT0 (PD2 - nCAN_INT pin).
 * The ISR is triggered by the reception of CAN messages.
 * 
 */
#ifndef CAN_INTERRUPT_DISABLE
ISR(INT0_vect) {
	mcp2515_get_message(&CAN_message_rx_buffer); // retrieve CAN message
	process_CAN_message();	
}
#endif