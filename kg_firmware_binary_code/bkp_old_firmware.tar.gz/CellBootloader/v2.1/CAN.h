// TODO credits

#ifndef __CAN_H__
#define __CAN_H__

/**** INCLUDES ****/

#include "platform.h" // include this file for platform-specific compilation

#ifndef KILOGUI
#include "stdint.h"
#include "mcp2515.h"
#endif

/**** DEFINES ****/

#define DISPATCHER_ID		0x01 // maximum priority given to the dispatcher in the CAN arbitration scheme
#define CELL_START_ID		0x0A // test ID for one cell

//#define CAN_INTERRUPT_DISABLE // disables the use of interrupts for the CAN

/**** TYPEDEFS AND ENUMS ****/

typedef enum{
    CAN_CELL_USER = 0x00,
    CAN_FORWARD_IR_MESSAGE = 0xA0,
    CAN_FORWARD_IR_MESSAGE_STOP,
    CAN_KILO_BOOTPAGE,
    CAN_KILO_BOOTPAGE_SIZE,
    CAN_KILO_BOOTPAGE_NUMBER,
    CAN_CELL_BOOT,
    CAN_CELL_BOOTPAGE,
    CAN_CELL_BOOTPAGE_SIZE,
    CAN_CELL_BOOTPAGE_NUMBER,
    CAN_CELL_KILOBOT_SETUP,
    CAN_CELL_IDLE,
    CAN_CELL_SETUP,
    CAN_CELL_RUN,
    CAN_CELL_PAUSE
} CAN_message_type_t;

/**** CALLBACKS DEFINITIONS ****/

#ifndef KILOGUI

typedef void (*CAN_message_rx_t)(CAN_message_t *);
//typedef void (*CAN_message_tx_success_t)(uint8_t);

extern CAN_message_rx_t cell_CAN_message_rx;
//extern CAN_message_tx_success_t cell_CAN_message_tx_success;

/**** FUNCTIONS PROTOTYPES ****/

void init_CAN_message(CAN_message_t *);
void init_CellCAN(void);
//uint8_t CAN_message_rx(CAN_message_t *);
void CAN_message_tx(CAN_message_t *);

#endif

#endif
