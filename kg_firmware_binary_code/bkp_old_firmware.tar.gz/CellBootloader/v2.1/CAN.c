// TODO header
/**** INCLUDES ****/

#include <avr/interrupt.h>

#include "CAN.h"
#include "mcp2515.h"
#include "mcp2515_defs.h"

#include "stdint.h"
#include "stdlib.h"
#include "debug.h"
#include "utils.h"

/**** VARIABLE DECLARATIONS ****/

CAN_message_t CAN_rx_message;

/**** FUNCTION POINTERS DECLARATIONS ****/

CAN_message_rx_t cell_CAN_message_rx;
//CAN_message_tx_success_t cell_CAN_message_tx_success; 

/**** PRIVATE FUNCTIONS ****/

/**** FUNCTION DEFINITIONS ****/

void init_CAN_message(CAN_message_t *m){
	uint8_t d;
	
	m->header.rtr = 0;
	m->header.length = 8;
	for(d = 0; d < 8; d++) m->data[d] = 0; // initialize all data bytes
}

void init_CellCAN(void){
	
	// variables
	init_CAN_message(&CAN_rx_message);
	
	// peripherals
	// set up CAN interrupt
	cli(); // turn off interrupts
	
	#ifndef CAN_INTERRUPT_DISABLE
	//EICRA |= (1 << ISC00);    // set INT0 to trigger on any logic change
	EICRA = 0; // interrupt triggered by a low level on INT0 and INT1
	EIMSK |= (1 << INT0);     // Turns on INT0
	#endif
	
	sei(); // turn on interrupts
	
	if(!init_mcp2515(CANSPEED_250)){
		cprints("ERROR: CAN could not initialize.");
	}
	
}

/**
 * @brief Functions that polls the mcp2515 chip to check if a message was received.
 * Returns a positive number if message reception was successful. 
 * @param pMessage Pointer to the received message. 
 */ 
// uint8_t CAN_message_rx(CAN_message_t *pMessage) {
// 
// 	if (mcp2515_check_message()) {
// 		if(mcp2515_get_message(pMessage) == 1){
// 			//cprints("gotmsg");
// 			return true;
// 		} 
// 		else{ 
// 			return false;
// 		}
// 	}
// 	else{
// 		return false;
// 	}
// }

void CAN_message_tx(CAN_message_t *message) {

	uint8_t msg_success;

	mcp2515_bit_modify(CANCTRL, (1<<REQOP2) | (1<<REQOP1) | (1<<REQOP0), 0);
	
	msg_success = mcp2515_send_message(message); // send message and store outcome
	//cell_CAN_message_tx_success(msg_success); // callback with the result of the transmission

}

/**
 * @brief Interrupt Service Routine for INT0 (PD2 - nCAN_INT pin)
 * 
 */
#ifndef CAN_INTERRUPT_DISABLE
ISR(INT0_vect) {
	mcp2515_get_message(&CAN_rx_message);
	// call callback function and pass message to the main
	cell_CAN_message_rx(&CAN_rx_message);
}
#endif