// TODO credits to kilolib.c
// TODO incorporate IR messaging part in CellIR.c and h

/**** INCLUDES ****/
#include <avr/wdt.h>        // watch dog timer
#include <avr/interrupt.h>
#include <avr/eeprom.h>     // read eeprom values
#include <stdlib.h>         // for rand()

#include "debug.h"

#include "Cell_lib.h"
#include "IO.h"
#include "CellLEDs.h"
#include "CAN.h"

/**** VARIABLE DECLARATIONS ****/uint16_t cell_uid;			// unique identifier (stored in EEPROM)

/**** FUNCTIONS DEFINITIONS ****/
void cell_init(void){

	cli(); // enter critical section - disable interrupts

	/* Peripherals */
	// disable watchdog
	//WDTCSR |= (1<<WDCE)|(1<<WDE); // re-enable if not working
	WDTCSR = 0;
		
	// Reset all MCU ports
	ports_off();

	// Setup peripherals
	init_serial();
	init_CellLEDs();
	init_CellCAN();

	/* Variables */
	// write cell UID in eeprom. The ID will be read by Cell_lib in the user program project
	eeprom_write_byte(CELL_EEPROM_UID_ADDR, CELL_EEPROM_UID_X_COORD & 0xFF); // LSB
    eeprom_write_byte(CELL_EEPROM_UID_ADDR+1, CELL_EEPROM_UID_Y_COORD & 0xFF); // MSB
	
	sei(); // exit critical section - enable interrupts
	
	cprints("Cell bootloader initialized.");
}

