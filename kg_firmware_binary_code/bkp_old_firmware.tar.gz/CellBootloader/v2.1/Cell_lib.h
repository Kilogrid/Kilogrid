// TODO: credits to the harvard kilobot firmware version 2

#ifndef __CELL_LIB_H__
#define __CELL_LIB_H__

/**** INCLUDES ****/
// #include "message.h"
// #include "message_send.h"

/**** MACROS ****/

#ifdef __cplusplus /* If this is a C++ compiler, use C linkage */
extern "C" {
#endif


/**** DEFINES ****/

#define F_CPU						8000000UL

// used by higher level functionalities (LEDs, IR, etc)
#define N_SUBCELLS					4 // cell revision A and B contain 4 subcells
#define SUBCELL_LOWER_INDEX			0x00
#define SUBCELL_UPPER_INDEX			SUBCELL_LOWER_INDEX + (N_SUBCELLS - 1) // subcells are numbered from SUBCELL_LOWER_INDEX to SUBCELL_HIGHER_INDEX

#define CELL_EEPROM_UID_ADDR		(uint8_t*)0xB2 // cell UID is placed after the kilobot 2-byte UID 
#define CELL_EEPROM_UID_X_COORD		3	
#define CELL_EEPROM_UID_Y_COORD		3

/**** TYPEDEFS AND ENUMS ****/

typedef void (*AddressPointer_t)(void) __attribute__ ((noreturn));

/*
 *	@brief Enumerates all possible cell states used in the experiments.
 */
typedef enum{
    IDLE,
    OBJECT,
	STIGMERGY
} cell_state_t;

/*
 *	@brief Enumerates all subcells addresses of the cell. 
 *  The addresses relate to their position in the MUXes and LED driver positions. 
 */
typedef enum{
	SC00 = SUBCELL_LOWER_INDEX,
	SC01 = SUBCELL_LOWER_INDEX + 1,
	SC02 = SUBCELL_LOWER_INDEX + 2, 
	SC03 = SUBCELL_LOWER_INDEX + 3
} subcell_num_t;

/**** PROTOTYPES ****/

/**
 * @brief Initialize cell hardware.
 *
 * This function initializes all hardware of the cell. This includes setting hardware timers,
 * configuring ports, setting up analog-to-digital converters,
 * registering system interrupts and the initializing the messaging
 * subsystem.
 * 
 * It is recommended that you call this function as early as possible
 * inside the `main` function of your program.
 */
void cell_init(void);

#endif //__CELL_LIB_H__
