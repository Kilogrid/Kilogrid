/** @internal */

#define EEPROM_VALID_APPLICATION_BIT_ADDR				(uint8_t *)0xB4			// used to check whether we have a valid application in the EEPROM. Set to 1 after bootloading.

typedef struct {
    uint8_t page_address;
    uint8_t page_offset;
    uint16_t word1;
    uint16_t word2;
    uint16_t word3;
    uint8_t unused;
} bootmsg_t;
