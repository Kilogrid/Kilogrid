#ifndef _BOOTPAGE_H_
#define _BOOTPAGE_H_

#define BOOTPAGE_SIZE                   128	 // number of bytes per boot page

#endif