// TODO header
/**** INCLUDES ****/

#include <avr/interrupt.h>

#include "CAN.h"
#include "mcp2515.h"
#include "mcp2515_defs.h"

#include "stdint.h"
#include "stdlib.h"
#include "debug.h"
#include "utils.h"

/**** VARIABLE DECLARATIONS ****/

CAN_message_t CAN_rx_message;

/**** FUNCTION POINTERS DECLARATIONS ****/

CAN_message_rx_t cell_CAN_message_rx;
CAN_message_tx_success_t cell_CAN_message_tx_success; 

/**** PRIVATE FUNCTIONS ****/

/**** FUNCTION DEFINITIONS ****/

void init_CAN_message(CAN_message_t *m){
	uint8_t d;
	
	m->header.rtr = 0;
	m->header.length = 8;
	for(d = 0; d < 8; d++) m->data[d] = 0; // initialize all data bytes
}

void init_CellCAN(void){
	
	// variables
	init_CAN_message(&CAN_rx_message);
	
	// peripherals
	// set up CAN interrupt
	cli(); // turn off interrupts
	
	EICRA |= (1 << ISC00);    // set INT0 to trigger on any logic change
	EIMSK |= (1 << INT0);     // Turns on INT0
	
	sei(); // turn on interrupts
	
	if(!init_mcp2515(CANSPEED_500)){
		cprints("ERROR: CAN could not initialize.");
	}
	
}

void CAN_message_tx(CAN_message_t *message) {

	uint8_t msg_success;

	mcp2515_bit_modify(CANCTRL, (1<<REQOP2) | (1<<REQOP1) | (1<<REQOP0), 0);
	
	msg_success = mcp2515_send_message(message); // send message and store outcome
	cell_CAN_message_tx_success(msg_success); // callback with the result of the transmission

}

void send_IR_message_through_CAN(IR_message_t *IR_message, uint8_t ID){
	uint8_t b;
	CAN_message_t CAN_message0;
	CAN_message_t CAN_message1;
	
	CAN_message0.id = ID;
	CAN_message0.header.length = 8;
	CAN_message0.number = 0;
	
	CAN_message1.id = ID;
	CAN_message1.header.length = 8;
	CAN_message1.number = 1;
	
	// copy IR message in two CAN messages
	CAN_message0.data[0] = IR_message->type; // byte 0 is IR message type
	
	// copy data bytes
	for(b = 1; b < CAN_MESSAGE_PAYLOAD; b++){
		CAN_message0.data[b] = IR_message->data[b - 1]; // copying bytes 0 to 6 of IR message into bytes 1 to 7 of CAN message data
	}
	
	// write remaining bytes into the second message
	for(b = CAN_MESSAGE_PAYLOAD; b < 9; b++){ // IR message payload contains 9 bytes
		CAN_message1.data[b - CAN_MESSAGE_PAYLOAD] = IR_message->data[b];
	}
	
	// send CAN messages
	CAN_message_tx(&CAN_message0);
	CAN_message_tx(&CAN_message1);
	
}

/**
 * @brief Interrupt Service Routine for INT0 (PD2 - nCAN_INT pin)
 * 
 */
ISR(INT0_vect) {
	if(mcp2515_get_message(&CAN_rx_message) == 1){ // get message from the CAN controller and pass its address to CAN_message_rx
		// call callback function and pass message to the main
		cell_CAN_message_rx(&CAN_rx_message);
	}
}