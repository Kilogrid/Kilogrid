// TODO credits to Kilolib v2

#include "message_crc.h"
#include "message_send.h"
#include "bootldr.h"
#include "IO.h"
#include "Dispatcher.h"
#include "debug.h"
#include "CAN.h"

#include <avr/io.h>        // for port and register definitions
#include <avr/interrupt.h> // for ISR
#include <util/delay.h>    // for _delay_ms
#include <string.h>        // for memcpy

/**
 * @brief Enumeration of the orders that the dispatcher can give to the cell.
 * TODO: define all orders required for the experiments (will take time)
 * TODO: transfer in the appropriate files of the project once the code for the Kilobot is part of the repo. 
 * 
 */
typedef enum{
	CELL_SET_COLOR = 0x00, // the color will be coded following the conventions of the cell
	CELL_GET_COLOR = 0x01,
	CELL_RESPONSE = 0x02 // sent by the kilobot when responding to a previous order (such as a GET)
} cell_order_t;

uint8_t packet_buffer[SERIAL_PACKET_SIZE];
uint8_t packet_head = 0;
uint8_t packet_checksum = 0;
serial_packet_raw_t serial_packet;
volatile uint8_t has_new_packet = 0;
volatile uint8_t tx_mask = 0;
volatile uint8_t leds_toggle = 0;
volatile uint8_t debug_2_toggle = 0;
volatile uint8_t fCAN_debug_rx;			// debugging of the CAN
volatile uint8_t fCAN_debug_tx;			// debugging of the CAN

volatile uint8_t fNew_CAN_Msg;

CAN_message_t can_msg;

uint8_t *rawmsg;
//message_t msg;
// bootmsg_t *bootmsg;
// gpsmsg_t *gpsmsg;

void dispatcher_init(void){
	cli();
	
	init_serial();
	    
	SET_AS_OUTPUT(DEBUG_1);
	SET_AS_OUTPUT(DEBUG_2);
	
	init_CellCAN();
	
	SET_AS_OUTPUT(nCAN_EN1);
	SET_AS_OUTPUT(nCAN_EN2);
	PIN_LOW(nCAN_EN1);
	PIN_LOW(nCAN_EN2);	

	sei();
}

void CAN_rx(CAN_message_t *m){
	fNew_CAN_Msg = 1;
	
}
void CAN_tx_success(uint8_t success){

	fCAN_debug_tx = !fCAN_debug_tx;
	if(fCAN_debug_tx){
		PIN_HIGH(DEBUG_1);
	}
	else{
		PIN_LOW(DEBUG_1);
	}
	
}

/*
 *	@brief Send received serial packets through the CAN bus, depending on their type.
 * TODO: remove this function and put it into CAN functions.
 * Also: put serial functions (like serial interrupt) in separate files for better code organization
 */
void send_serial_packet_through_CAN(serial_packet_raw_t *s, uint16_t CAN_ID){
	
	uint8_t i;
	serial_packet_type_t type = s->type; // store serial packet type
	IR_message_t IR_message;
	
	switch(type){
		case PACKET_FORWARDMSG:
			// get IR message contained in the serial packet and send it through CAN
			// TODO: introduce ID
			for(i = 0; i < 9; i++){ // 9 is the number of data bytes per IR message
				IR_message.data[i] = s->data[i];
			}
			IR_message.type = s->data[11];
			send_IR_message_through_CAN(&IR_message, CAN_ID); // encapsulate and send IR message through CAN
			
			break;
		case PACKET_BOOTPAGE: // TODO
			break;
		default:
			break;
	}
	
}

int main() {
	uint8_t i;
//     bootmsg = (bootmsg_t*)msg.data;
//     gpsmsg = (gpsmsg_t*)msg.data;
//     rawmsg = (uint8_t*)&msg;

	// register function callbacks
	cell_CAN_message_rx = CAN_rx;
	cell_CAN_message_tx_success = CAN_tx_success;

	dispatcher_init();

    // Use LEDs to flash power on indicator signal
    for (i = 0; i < 5; i++) {
        PIN_HIGH(DEBUG_1);
        _delay_ms(200);
        PIN_LOW(DEBUG_1);
        _delay_ms(200);
    }
	
	fCAN_debug_rx = 0;
	fCAN_debug_tx = 0;
			
	init_CAN_message(&can_msg);
			
	// TODO: message filtering - adapt message ID to all messages sent
	can_msg.id = DISPATCHER_ID;
	
	cprints("Dispatcher initialized.");

    while(1) {
				
        if (has_new_packet) { // received a new packet on the serial
            has_new_packet = 0; // reset flag
			
            switch(serial_packet.type) {
				// do not send packets through CAN for these serial packets types
				case PACKET_STOP:
					break;
				case PACKET_LEDTOGGLE: // received LED toggle serial packet
					leds_toggle = !leds_toggle;
					if (leds_toggle) {
						PIN_HIGH(DEBUG_2);
					} 
					else {
						PIN_LOW(DEBUG_2);
					}
					break;
				
				default: 
					send_serial_packet_through_CAN(&serial_packet, DISPATCHER_ID); // TODO introduce CAN ID
					break;
            }
        }
		
    } // while 1

    return 0;
}

/**
 * @brief Interrupt service routine for incoming serial packets of data.
 * Each incoming byte is stored in the UDR0 register and saved at the beginning of the ISR.
 * The main function implements the actions to take for each packet type.
 * 
 */
ISR(USART_RX_vect) {
    uint8_t rx = UDR0;

    packet_checksum ^= packet_buffer[packet_head];
    packet_buffer[packet_head] = rx; // store received byte in packet buffer
    packet_checksum ^= rx;
    packet_head++;
	
    if (packet_head >= SERIAL_PACKET_SIZE)
        packet_head = 0;

    if (packet_buffer[packet_head] == SERIAL_PACKET_HEADER) { // packet_head == 0 --> points toward packet header (end of last serial packet)
        if (packet_checksum == 0) { // if no errors detected
            uint16_t i;
			
			// copy packet buffer into serial packet struct
			serial_packet.header = packet_buffer[0]; // byte 0 is the packet header
			serial_packet.type = packet_buffer[1]; // byte 1 is the packet type
			
            for (i = 2; i < SERIAL_PACKET_SIZE; i++){
                serial_packet.data[i - 2] = packet_buffer[i]; // copy packet payload into data field 
			}
            has_new_packet = 1; // signify new arrival of packet to main loop
        }
    }
}
