// TODO credits

/* Copyright (c) 2007 Fabian Greif
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
* 1. Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
*
* THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS "AS IS" AND
* ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
* ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
* FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
* DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
* OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
* LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
* SUCH DAMAGE.
*/
// ----------------------------------------------------------------------------

#ifndef __CAN_H__
#define __CAN_H__

/**** INCLUDES ****/

#include "stdint.h"
#include "mcp2515.h"
#include "message.h"

/**** DEFINES ****/

#define DISPATCHER_ID		0x01 // maximum priority given to the dispatcher in the CAN arbitration scheme
#define CELL_START_ID		0x0A // test ID for one cell

#define CAN_MESSAGE_SIZE	8

/**** CALLBACKS DEFINITIONS ****/

typedef void (*CAN_message_rx_t)(CAN_message_t *);
typedef void (*CAN_message_tx_success_t)(uint8_t);

extern CAN_message_rx_t cell_CAN_message_rx;
extern CAN_message_tx_success_t cell_CAN_message_tx_success;

/**** FUNCTIONS PROTOTYPES ****/

void init_CAN_message(CAN_message_t *);
void init_CellCAN(void);
//uint8_t CAN_message_rx(CAN_message_t *);
void CAN_message_tx(CAN_message_t *);
void send_IR_message_through_CAN(IR_message_t *, uint8_t);

#endif
