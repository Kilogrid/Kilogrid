#ifndef __KILOB_MESSAGING_H__
#define __KILOB_MESSAGING_H__

#include "message.h"

void kilob_messaging_init();
IR_message_t* kilob_message_send();

#endif