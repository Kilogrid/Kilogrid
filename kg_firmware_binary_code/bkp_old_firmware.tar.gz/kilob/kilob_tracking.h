#ifndef __KILOB_TRACKING_H__
#define __KILOB_TRACKING_H__

#include "kilogrid.h"

void kilob_tracking_init();
void kilob_tracking(tracking_user_data_t* data);

#endif
