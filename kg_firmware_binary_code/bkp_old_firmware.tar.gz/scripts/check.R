check.dir <- dirname(sys.frame(1)$ofile)

source(paste(check.dir, "process.R", sep="/"))


main <- function(filename, plot=T) {
  df <- read.kilodat(filename)
  bots <- check.count_kilobots(df)
  data <- check.count_data(df)
  print(data)
  if(plot) {
    plot(data, ylim=c(1, max(df$timestamp)/(32*2)), main=paste("Number of kilobots =", bots), ylab="Count data")
  }
}


check.count_kilobots <- function(df) {
  length(unique(df$kilobot_sn))
}


check.count_data <- function(df) {
  kilobot <- unique(df$kilobot_sn)
  counts <- sapply(kilobot, function(id){ nrow(subset(df, kilobot_sn == id)) })
  data.frame(kilobot_sn = kilobot, count = counts)
}
