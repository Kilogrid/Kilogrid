TICKS_PER_SEC  <- 31
NUM_SUBCELLS_X <- 20
NUM_SUBCELLS_Y <- 40

# Keep current data
kilodat <- data.frame()

# Reset number of subcells
kilodat.subcells <- function(x = NUM_SUBCELLS_X, y = NUM_SUBCELLS_Y) {
  assign("NUM_SUBCELLS_X", x, envir = .GlobalEnv)
  assign("NUM_SUBCELLS_Y", y, envir = .GlobalEnv)
}


# Main
# param filename  [required] kilodat file name
# param start_t   [optional] start time
# param end_t     [optional] end time (if end <= start, end time is automatically detected using loaded data)
# param savePDF   [optional] flag to save heatmap as PDF
# param stats     [optional] flag to show stats
# param saveTrans [opiotnal] flag to generate transitions
# param intr      [optional] interval time for generating transition [min.]
main <- function(filename, start_t = 0, end_t = 0, savePDF = F, stats = T, saveTrans = F, intr = 30) {
  # Read kilodat
  df <- read.kilodat(filename)

  kilodat.main.process(df, start_t, end_t, savePDF, filename, stats)
  if(saveTrans) {
    kilodat.save_transition(df, start_t, end_t, intr, filename)
  }
}


# Main process called in main
# param df       [required] kilodat data frame
# param start_t  [optional] start time
# param end_t    [optional] end time (if end <= start, end time is automatically detected using loaded data)
# param savePDF  [optional] flag to save heatmap as PDF
# param filename [optional] file base name for PDF
# param stats    [optional] flag to show stats
kilodat.main.process <- function(df, start_t = 0, end_t = 0, savePDF = F, filename = "process", stats = T) {
  # Detect end time if required
  end_t <- kilodat.detect_end_time(df, start_t, end_t)

  # Generate map {position => time [sec]}
  pos_dt <- kilodat.calc_position_time(df, start_t, end_t)

  # Make matrix (x, y) -> time
  m <- kilodat.pos_dt.convert_into_matrix(pos_dt, NUM_SUBCELLS_X, NUM_SUBCELLS_Y)

  # Draw heatmap
  kilodat.heatmap(m, filename, savePDF)

  # Show stats
  if(stats) {
    kilodat.get_stats(m)
  }
}


# Generate time transitions
# param df     [required] kilodat data frame
# param target [optional] extraction target from data frame
# return A list of matrices in which first column is timestamp, and other columns coorespond to data specified by target parameter
kilodat.transitions <- function(df, target=c("x", "y", "data0", "data1", "data2", "data3")) {
  end_t <- max(df$timestamp)
  lapply(kilodat.divide.kilobot(df),
         function(data){
           tr <- (1:length(target)) + 1
           dm <- data.matrix(data[,target])
           dm
           mat <- matrix(1:end_t, ncol = length(target) + 1, nrow = end_t)
           mat <- t(mat)
           mat[tr, 1:data[1,]$timestamp] <- dm[1,]
           for(r in 1:(nrow(data) - 1)) {
             mat[tr, data$timestamp[r]:data$timestamp[r+1]] <- dm[r,]
           }
           mat[tr, max(data$timestamp):end_t] <- dm[nrow(data),]
           ret <- as.data.frame(t(mat))
           names(ret) <- c("timestamp", target)
           ret
         })
}


# Save transitions as PDF
# param df       [required] kilodat data frame
# param start_t  [optional] start time
# param end_t    [optional] end time (if end <= start, end time is automatically detected using loaded data)
# param intr     [optional] interval time for generating transition [min.]
# param filename [optional] file base name for PDF
kilodat.save_transition <- function(df, start_t = 0, end_t = 0, intr = 5, filename = "transition") {
  # Detect end time & filtering
  end_t <- kilodat.detect_end_time(df, start_t, end_t)

  # Calculate interval
  interval <- seq(start_t, end_t, TICKS_PER_SEC * intr * 60)
  if(interval[length(interval)] < end_t) {
    interval <- c(interval, end_t)
  }

  # Make time-windows
  chunks <- lapply(1:(length(interval)-1),
                   function(i){
                     data.frame(start = interval[i], end = interval[i+1])
                   })

  # Generate heatmap as PDF for each time-window
  for(chunk in chunks) {
    cat("# Processing chunk from", chunk$start, "to", chunk$end, "\n")
    fname <- paste(filename, chunk$start, chunk$end, sep="_")
    kilodat.main.process(df, start_t=chunk$start, end_t=chunk$end, savePDF=T, filename=fname, stats=F)
  }
}


# Read kilodat with cell coordinates
read.kilodat <- function(filename) {
  df <- read.table(filename, header=T, sep="\t")
  df <- kilodat.append_coordinate(df)
  df[sort.list(df$timestamp),]
  assign("kilodat", df, envir = .GlobalEnv)
}


# End time detection
kilodat.detect_end_time <- function(df, start_t, end_t) {
  if(end_t <= start_t) {
    max(df$timestamp)
  } else {
    end_t
  }
}


# Generate unordered map {position => time}
kilodat.calc_position_time <- function(df, start_t = 0, end_t = max(df$timestamp)) {
  # Filtering
  used_data <- kilodat.filter.timestamp(df, start_t, end_t)
  used_data <- used_data[,c("x", "y", "kilobot_sn", "timestamp")]
  # Divide data by kilobot_sn & sort by timestamp
  data_list <- lapply(kilodat.divide.kilobot(used_data),
                      function(data){
                        data[order(data$timestamp),]
                      })
  # Get position & dt for each kilobot
  pos_dt <- lapply(data_list,
                   function(ud){
                     time <- c(ud$timestamp, end_t)
                     time[1] <- start_t
                     data.frame(
                       ud,
                       dt = diff(time)
                     )
                   })
  # Merge all list
  pos_dt <- Reduce(function(d1, d2){
                     data.frame(x = c(d1$x, d2$x), y = c(d1$y, d2$y), dt = c(d1$dt, d2$dt))
                   }, pos_dt)
  # Divide data by position
  pos_dt <- kilodat.divide.cell(pos_dt)
  # Get map position => time spent on the position
  pos_dt <- lapply(pos_dt, function(data){
                             data.frame(
                               x = data$x[1],
                               y = data$y[1],
                               dt = Reduce(sum, data$dt)/TICKS_PER_SEC)
                           })
  #pos_dt <- Reduce(function(d1, d2){
  #                   data.frame(x = c(d1$x, d2$x), y = c(d1$y, d2$y), dt = c(d1$dt, d2$dt))
  #                 }, pos_dt)
  # Reduce(function(d1, d2){
  #          data.frame(x = c(d1$x, d2$x), y = c(d1$y, d2$y), dt = c(d1$dt, d2$dt))
  #        }, pos_dt)
  Reduce(function(d1, d2){ rbind(d1, d2) }, pos_dt)
}


# Convert map {pos => time} into matrix
kilodat.pos_dt.convert_into_matrix <- function(pos_dt, row, col) {
  ret <- matrix(0, nrow=row, ncol=col)
  for(i in 1:length(pos_dt$dt)) {
    ret[pos_dt$x[i], pos_dt$y[i]] <- pos_dt$dt[i]
  }
  ret
}


# Coordinates
kilodat.get_coord_x <- function(x, sc) {
  x * 2 + sc %% 2 + 1
}


kilodat.get_coord_y <- function(y, sc) {
  y * 2 + (1 - sc %/% 2) + 1
}


kilodat.append_coordinate <- function(df) {
  pos <- as.matrix(df[,c("cellx", "celly", "sc")])
  cx  <- apply(pos, MARGIN=1, function(p){ kilodat.get_coord_x(p[1], p[3]) })
  cy  <- apply(pos, MARGIN=1, function(p){ kilodat.get_coord_y(p[2], p[3]) })
  data.frame(df, x = cx, y = cy)
}


# Filter
kilodat.filter.timestamp <- function(df, start_t, end_t) {
  subset(df, timestamp >= start_t & timestamp <= end_t)
}


kilodat.reject.kilobot <- function(df, kilobot) {
  subset(df, kilobot_sn != kilobot)
}


# For each kilobot
kilodat.each_kilobot.count_data <- function(df) {
  kilobots <- as.vector(unique(df$kilobot_sn))
  counted <- lapply(kilobots,
                    function(kilobot){
                      sb <- subset(df, kilobot_sn == kilobot)
                      data.frame(kilobot_sn = kilobot, count = length(sb$timestamp) )
                    })
  Reduce(function(d1, d2){
           data.frame(
             kilobot_sn = c(as.character(d1$kilobot_sn), as.character(d2$kilobot_sn)),
             count = c(d1$count, d2$count)
           )
         }, counted)
}


# Divide data (these functions are heavy)
kilodat.divide.kilobot <- function(df) {
  ret <- lapply(unique(df$kilobot_sn),
                function(kilobot){
                  subset(df, kilobot_sn == kilobot)[, names(df) != "kilobot_sn"]
                })
  names(ret) <- unique(df$kilobot_sn)
  ret
}


kilodat.divide.cell <- function(df) {
  cells <- df[!duplicated(data.frame(df$x, df$y)), c("x", "y")]
  apply(as.matrix(cells), MARGIN=1, function(cell){ subset(df, x == cell[1] & y == cell[2]) })
}


##########################################################################
# This function is to draw the lengend in the plot..
# Copy and pasted from the web.. don't know what it does, but it works.
##########################################################################
image.scale <- function(z, zlim, col = heat.colors(12),
                        breaks, horiz=TRUE, ylim=NULL, xlim=NULL, ...){
  if(!missing(breaks)){
    if(length(breaks) != (length(col)+1)){stop("must have one more break than colour")}
  }
  if(missing(breaks) & !missing(zlim)){
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
  }
  if(missing(breaks) & missing(zlim)){
    zlim <- range(z, na.rm=TRUE)
    zlim[2] <- zlim[2]+c(zlim[2]-zlim[1])*(1E-3)#adds a bit to the range in both directions
    zlim[1] <- zlim[1]-c(zlim[2]-zlim[1])*(1E-3)
    breaks <- seq(zlim[1], zlim[2], length.out=(length(col)+1))
  }
  poly <- vector(mode="list", length(col))
  for(i in seq(poly)){
    poly[[i]] <- c(breaks[i], breaks[i+1], breaks[i+1], breaks[i])
  }
  xaxt <- ifelse(horiz, "s", "n")
  yaxt <- ifelse(horiz, "n", "s")
  if(horiz){YLIM<-c(0,1); XLIM<-range(breaks)}
  if(!horiz){YLIM<-range(breaks); XLIM<-c(0,1)}
  if(missing(xlim)) xlim=XLIM
  if(missing(ylim)) ylim=YLIM
  plot(1,1,t="n",ylim=ylim, xlim=xlim, xaxt=xaxt, yaxt=yaxt, xaxs="i", yaxs="i", ...)
  for(i in seq(poly)){
    if(horiz){
      polygon(poly[[i]], c(0,0,1,1), col=col[i], border=NA)
    }
    if(!horiz){
      polygon(c(0,0,1,1), poly[[i]], col=col[i], border=NA)
    }
  }
}


# Copied from original process.R
kilodat.heatmap <- function(m, pdfName="", savePDF=FALSE) {
  cexLab      <- 1.75
  cexAxis     <- 1.75
  lwdLines    <- 2.35
  lwdGrid     <- 1.5
  pdfHeight   <- 5.2
  pdfWidth    <- 7
  marLeft     <- 5
  marTop      <- 0.5
  marRight    <- 3
  marBottom   <- 4.

  if (savePDF) {
    pdfName <- paste(pdfName, ".pdf", sep="")
    pdf(pdfName, height=pdfHeight, width=pdfWidth)
    par(mar=c(marBottom, marLeft, marTop+1.5, marRight))
  }

  max_value_ind = which(m == max(m), arr.ind = TRUE)[1,]
  max_value = m[max_value_ind[1], max_value_ind[2]]

  colPalGray <- gray.colors(30,start=0.1,end=0.9)

  layout(matrix(c(1,2), nrow=1, ncol=2), widths=c(5,1))

  image(0:NUM_SUBCELLS_X,
        0:NUM_SUBCELLS_Y,
        m,
        col=colPalGray,
        zlim=c(1,max_value),
        main="Spatial distribution",
        xlab="x",
        ylab="y",
        cex.lab=cexLab,
        cex.main=cexLab,
        cex.axis=cexAxis,
        #        useRaster=T,
        axes=FALSE)


  aX <- seq(0, NUM_SUBCELLS_X, 2)
  axis(1, cex.axis=cexAxis, at=aX)
  aY <- seq(0, NUM_SUBCELLS_Y,5)
  axis(2, at=aY, cex.axis=cexAxis, las=2)

  grid(nx=NUM_SUBCELLS_X,ny=NUM_SUBCELLS_Y,col="gray50",lwd=lwdGrid)

  par(mar=c(3.8,0,2,5))
  breaks <- seq(min(m), max(m),length.out=31)
  image.scale(m, col=colPalGray, breaks=breaks, horiz=!TRUE,xaxt="n",yaxt="n")
  axis(4,at=breaks[c(seq(1,30,2),31)], las=2)
  box()

  if (savePDF) {
    dev.off()
    cat("# Heatmap generated into", pdfName, "\n")
  }
}


# Copied from original process.R
kilodat.get_stats <- function(mat){
  # Probability to stay in the working area
  pWork <- 0
  matTmp <- mat
  matTmp[1,] <- 0
  matTmp[,1] <- 0
  matTmp[dim(mat)[1],] <- 0
  matTmp[,dim(mat)[2]] <- 0
  pWork <- sum(matTmp)/sum(mat)
  pWalls <- 1- pWork
  cat("The swarm spends", pWork*100, "% of its time in the working area and",
      pWalls*100, "% of its time on the walls\n")

  # Does the swarm distribute uniformely?
  matTmp <- mat[2:(dim(mat)[1]-1),2:(dim(mat)[2]-1)]
  matTmp <- matTmp/sum(mat)

  cat("The mean probability to for a robot to stay on a cell in the working area is", mean(matTmp),
      "and the standard deviation is",sd(matTmp),"\n")

  corners <- kilodat.get_corner_stats(mat)

  cat("Time spent in each quadrant:\n TL = ", corners[1], "\n TR = ", corners [2], "\n BL = ", corners[3], "\n BR = ", corners[4], "\n")
  cat("Proportion of time spent in each quadrant:\n TL = ", corners[1]/sum(corners)*100, "\n TR = ", corners[2]/sum(corners)*100, "\n BL = ", corners[3]/sum(corners)*100, "\n BR = ", corners[4]/sum(corners)*100, "\n")

}


# Copied from original process.R
kilodat.get_corner_stats <- function(m){
  # TL, TR, BL, BR
  res <- c(0,0,0,0)

  half_x <- NUM_SUBCELLS_X/2
  half_y <- NUM_SUBCELLS_Y/2

  BL <- sum(m[1:half_x, 1:half_y])
  BR <- sum(m[(half_x+1):NUM_SUBCELLS_X, 1:half_y])
  TL <- sum(m[1:half_x, (half_y+1):NUM_SUBCELLS_Y])
  TR <- sum(m[(half_x+1):NUM_SUBCELLS_X, (half_y+1):NUM_SUBCELLS_Y])

  res <- c(TL, TR, BL, BR)

  res

}
